#!/system/bin/sh

MODDIR=${0%/*}
HSIN_LOG="$MODDIR/hsin.log"

rm -f "$MODDIR/hsin.log" 2>/dev/null
rm -f "$MODDIR/hsin_ui.log" 2>/dev/null
rm -f "$MODDIR"/diagnostic_*.txt 2>/dev/null
rm -f "$MODDIR/.feature_status" 2>/dev/null
rm -f "$MODDIR/.profile_status" 2>/dev/null
rm -f "$MODDIR/.profile_state" 2>/dev/null
rm -f "$MODDIR/.progress" 2>/dev/null
rm -f "$MODDIR/.progress_log" 2>/dev/null
rm -f "$MODDIR/.apply_dedup" 2>/dev/null
rm -f "$MODDIR/.job_pid" 2>/dev/null
rm -rf "$MODDIR/.rollback" 2>/dev/null
rm -rf "$MODDIR/.hsin_state" 2>/dev/null

pkill -f "hsin_game_mode" 2>/dev/null
pkill -f "hsin_powersave" 2>/dev/null

echo "" > "$MODDIR/.game_state" 2>/dev/null
echo "" > "$MODDIR/.current_game" 2>/dev/null

. "$MODDIR/lib/hsin_common.sh"
. "$MODDIR/lib/hsin_detect.sh"

hsin_detect_all

vlkn() {
    resetprop -n renderthread.vulkanthreaded.reduceopstasksplitting true
    resetprop -n ro.hwui.hardware.vulkan true
    resetprop -n ro.hwui.use_vulkan true
    resetprop -n ro.ui.pipeline skiavk
    resetprop -n ro.hwui.skia.show_vulkan_pipeline true
    resetprop -n debug.hwui.renderer skiavk
    resetprop -n vendor.debug.renderengine.backend skiavk
    resetprop -n debug.renderengine.backend skiavk
    resetprop -n ro.ui.pipeline vulkan
    resetprop -n debug.hwui.level high
    resetprop -n debug.overlayui.enable 1
    resetprop -n debug.performance.tuning 1
    resetprop -n hwui.render_dirty_regions false
    resetprop -n hwui.disable_vsync true
    resetprop -n persist.cpu.freq.boost 1
    resetprop -n debug.hwui.render_dirty_regions false
    resetprop -n persist.sys.disable_skia_path_ops false
    resetprop -n ro.config.hw_high_perf true
    resetprop -n debug.hwui.disable_scissor_opt true
    resetprop -n debug.vulkan.layers.enable 1
    resetprop -n persist.device_config.surface_flinger_native_boot.SkiaTracingFeature__use_skia_tracing true
    resetprop -n persist.sys.composition.type gpu
    resetprop -n debug.composition.type gpu
    resetprop -n debug.hwui.show_dirty_regions false
    resetprop -n debug.hwui.use_gpu_pixel_buffers false
    resetprop -n debug.hwui.use_buffer_age false
    resetprop -n persist.sys.perf.topAppRenderThreadBoost.enable true
}

NR() {
    hsin_set_gov schedutil
    hsin_apply 1 /sys/devices/system/cpu/cpu1/online
}

if [ -f "$MODDIR/.selected_option" ]; then
    SELECTED=$(cat "$MODDIR/.selected_option")
    case "$SELECTED" in
        1) vlkn ;;
        2) NR ;;
        3) echo "Skipped performance tweaks." ;;
    esac
fi

hsin_game_mode() {
    LOG="$MODDIR/hsin.log"
    alog() { echo "$(date +%H:%M:%S) [GameMode] $1" >> "$LOG"; }

    GAME_STATE="IDLE"
    CURRENT_GAME=""
    CURRENT_PROFILE=""
    LAST_APPLIED=""
    PREV_FG=""

    resolve_profile() {
        _pkg="$1"
        if grep -qx "$_pkg" "$MODDIR/Misc/Game.txt" 2>/dev/null; then
            echo "performance"
        else
            echo "balanced"
        fi
    }

    apply_profile() {
        _target="$1"
        _pkg="$2"
        [ -z "$_target" ] && return

        if [ "$_target" = "$LAST_APPLIED" ] && [ "$_pkg" = "$CURRENT_GAME" ]; then
            return
        fi

        alog "Applying profile=$_target for pkg=$_pkg"

        _pf="$MODDIR/.job_pid"
        if [ -f "$_pf" ]; then
            _prev_pid="$(cat "$_pf" 2>/dev/null | cut -d'|' -f2)"
            if [ -n "$_prev_pid" ] && kill -0 "$_prev_pid" 2>/dev/null; then
                kill -TERM "$_prev_pid" 2>/dev/null
                _w=0
                while kill -0 "$_prev_pid" 2>/dev/null && [ "$_w" -lt 20 ]; do sleep 0.1; _w=$((_w+1)); done
                kill -0 "$_prev_pid" 2>/dev/null && kill -KILL "$_prev_pid" 2>/dev/null
            fi
        fi

        _job_id="auto_$(date +%s)_$$"
        sh "$MODDIR/apply-profile.sh" "$_target" "$_job_id" >/dev/null 2>&1 &
        am broadcast -n com.cleverdumb.hsinwebui/.ApplyProfileReceiver --es profile "$_target" >/dev/null 2>&1

        LAST_APPLIED="$_target"
        CURRENT_PROFILE="$_target"
        echo "$_target" > "$MODDIR/.applied_mode" 2>/dev/null
        echo "$_pkg|$_target|$( [ -n "$_pkg" ] && echo 1 || echo 0 )" > "$MODDIR/.auto_status" 2>/dev/null
    }

    dnd_save_state() {
        DND_WAS_ON=""
        _zen=$(su -c "dumpsys notification" 2>/dev/null | grep -E "mZenMode=" | head -1 | grep -v "OFF")
        if [ -n "$_zen" ]; then
            DND_WAS_ON="1"
            return
        fi
        if command -v settings >/dev/null 2>&1; then
            _zen=$(su -c "settings get secure zen_mode" 2>/dev/null)
            if [ -n "$_zen" ] && [ "$_zen" != "null" ] && [ "$_zen" != "0" ]; then
                DND_WAS_ON="1"
                return
            fi
        fi
    }

    dnd_apply() {
        [ -f "$MODDIR/.game_dnd" ] || return
        [ "$(cat "$MODDIR/.game_dnd" 2>/dev/null)" != "1" ] && return
        if command -v cmd >/dev/null 2>&1; then
            dnd_save_state
            su -c "cmd notification set_dnd on" >/dev/null 2>&1
            alog "DND enabled for gaming (previous state: ${DND_WAS_ON:-unknown})"
        fi
    }

    dnd_restore() {
        [ -f "$MODDIR/.game_dnd" ] || return
        [ "$(cat "$MODDIR/.game_dnd" 2>/dev/null)" != "1" ] && return
        if command -v cmd >/dev/null 2>&1; then
            if [ "$DND_WAS_ON" = "1" ]; then
                alog "DND was already on before gaming, leaving enabled"
            else
                su -c "cmd notification set_dnd off" >/dev/null 2>&1
                alog "DND restored to off"
            fi
        fi
    }

    enter_game() {
        _pkg="$1"
        [ "$_pkg" = "$CURRENT_GAME" ] && return
        [ -z "$_pkg" ] && return

        CURRENT_GAME="$_pkg"
        GAME_STATE="GAME_ACTIVE"
        echo "$_pkg" > "$MODDIR/.current_game" 2>/dev/null
        echo "GAME_ACTIVE" > "$MODDIR/.game_state" 2>/dev/null

        _target=$(resolve_profile "$_pkg")
        apply_profile "$_target" "$_pkg"
        dnd_apply

        alog "GAME_ACTIVE: $_pkg (profile=$_target)"
    }

    exit_game() {
        [ "$GAME_STATE" != "GAME_ACTIVE" ] && return
        [ -z "$CURRENT_GAME" ] && return

        dnd_restore

        _old_game="$CURRENT_GAME"
        CURRENT_GAME=""
        GAME_STATE="IDLE"
        echo "" > "$MODDIR/.current_game" 2>/dev/null
        echo "IDLE" > "$MODDIR/.game_state" 2>/dev/null

        _global=$(cat "$MODDIR/.current_mode" 2>/dev/null)
        [ -z "$_global" ] && _global="balanced"
        apply_profile "$_global" ""

        alog "IDLE: exited game $_old_game, restored to $_global"
    }

    check_power_save() {
        _ps=""
        if command -v settings >/dev/null 2>&1; then
            _raw=$(su -c "settings get global low_power" 2>/dev/null)
            [ "$_raw" = "1" ] && _ps="1"
        fi
        if [ -z "$_ps" ] && command -v cmd >/dev/null 2>&1; then
            _raw=$(su -c "cmd power get-low-power-mode" 2>/dev/null)
            case "$_raw" in
                *1*|*true*|*on*) _ps="1" ;;
            esac
        fi

        if [ "$_ps" = "1" ]; then
            if [ "$GAME_STATE" != "POWER_SAVE" ]; then
                GAME_STATE="POWER_SAVE"
                echo "POWER_SAVE" > "$MODDIR/.game_state" 2>/dev/null
                apply_profile "battery" ""
                alog "POWER_SAVE: battery saver activated"
            fi
            return 0
        fi
        return 1
    }

    exit_power_save() {
        if [ "$GAME_STATE" = "POWER_SAVE" ]; then
            if [ -n "$CURRENT_GAME" ]; then
                _target=$(resolve_profile "$CURRENT_GAME")
                apply_profile "$_target" "$CURRENT_GAME"
                GAME_STATE="GAME_ACTIVE"
                echo "GAME_ACTIVE" > "$MODDIR/.game_state" 2>/dev/null
                alog "POWER_SAVE ended: restored game profile for $CURRENT_GAME"
            else
                _global=$(cat "$MODDIR/.current_mode" 2>/dev/null)
                [ -z "$_global" ] && _global="balanced"
                apply_profile "$_global" ""
                GAME_STATE="IDLE"
                echo "IDLE" > "$MODDIR/.game_state" 2>/dev/null
                alog "POWER_SAVE ended: restored to $_global"
            fi
        fi
    }

    get_foreground_pkg() {
        _fg=""
        if command -v cmd >/dev/null 2>&1; then
            _fg=$(su -c "cmd window" 2>/dev/null | grep -E 'mCurrentFocus|mFocusedApp' | grep -oE '[a-zA-Z][a-zA-Z0-9_.]+/[a-zA-Z0-9_.]+' | head -1 | cut -d/ -f1)
        fi
        if [ -z "$_fg" ]; then
            _fg=$(su -c "dumpsys window" 2>/dev/null | grep -E 'mCurrentFocus' | grep -oE '[a-zA-Z][a-zA-Z0-9_.]+/[a-zA-Z0-9_.]+' | head -1 | cut -d/ -f1)
        fi
        if [ -z "$_fg" ]; then
            _fg=$(su -c "dumpsys activity activities" 2>/dev/null | grep -E 'topResumedActivity' | grep -oE 'u0 [a-zA-Z0-9._]+' | awk '{print $2}' | head -1)
        fi
        echo "$_fg"
    }

    process_fg() {
        _fg="$1"
        [ -z "$_fg" ] && return

        [ "$_fg" = "$PREV_FG" ] && return

        case "$_fg" in
            com.android.systemui|surfaceflinger|system_server)
                PREV_FG="$_fg"
                return
                ;;
        esac

        if check_power_save; then
            PREV_FG="$_fg"
            return
        fi

        exit_power_save

        _is_game=0
        grep -qx "$_fg" "$MODDIR/Misc/Game.txt" 2>/dev/null && _is_game=1

        if [ "$_is_game" = "1" ]; then
            enter_game "$_fg"
        else
            if [ "$GAME_STATE" = "GAME_ACTIVE" ]; then
                exit_game
            fi
        fi

        PREV_FG="$_fg"
    }

    alog "Game Mode engine started (lightweight polling, interval=2s)"

    while true; do
        AUTO=$(cat "$MODDIR/.auto_mode" 2>/dev/null)
        if [ "$AUTO" != "1" ]; then
            echo "0" > "$MODDIR/.auto_applied" 2>/dev/null
            echo "|balanced|0" > "$MODDIR/.auto_status" 2>/dev/null
            LAST_APPLIED=""
            CURRENT_GAME=""
            GAME_STATE="IDLE"
            while :; do
                sleep 1
                AUTO=$(cat "$MODDIR/.auto_mode" 2>/dev/null)
                [ "$AUTO" = "1" ] && break
            done
            alog "Game Mode toggled ON, starting detection"
            continue
        fi

        FG=$(get_foreground_pkg)
        [ -n "$FG" ] && process_fg "$FG"

        sleep 2
    done
}

hsin_powersave_monitor() {
    LOG="$MODDIR/hsin.log"
    _prev_ps=""

    while true; do
        sleep 10

        _ps=""
        if command -v settings >/dev/null 2>&1; then
            _raw=$(su -c "settings get global low_power" 2>/dev/null)
            [ "$_raw" = "1" ] && _ps="1"
        fi
        if [ -z "$_ps" ] && command -v cmd >/dev/null 2>&1; then
            _raw=$(su -c "cmd power get-low-power-mode" 2>/dev/null)
            case "$_raw" in
                *1*|*true*|*on*) _ps="1" ;;
            esac
        fi

        if [ "$_ps" != "$_prev_ps" ]; then
            _prev_ps="$_ps"
            if [ "$_ps" = "1" ]; then
                echo "$(date +%H:%M:%S) [PowerSave] Battery saver activated" >> "$LOG" 2>/dev/null
            else
                echo "$(date +%H:%M:%S) [PowerSave] Battery saver deactivated" >> "$LOG" 2>/dev/null
            fi
        fi
    done
}

hsin_game_mode &
hsin_powersave_monitor &

exit 0
