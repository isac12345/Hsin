#!/system/bin/sh

_hsin_read() { tr -d '\0' < "$(hsin_syspath "$1")" 2>/dev/null | sed 's/^[[:space:]]*//;s/[[:space:]]*$//'; }

hsin_detect_soc() {
	HSIN_SOC_VENDOR="unknown"
	HSIN_SOC_MODEL="unknown"

	if [ -f "$(hsin_syspath /proc/device-tree/compatible)" ]; then
		_compat="$(_hsin_read /proc/device-tree/compatible | tr ' ' '\n' | head -n 1)"
		case "$_compat" in
			*unisoc*|*sp[0-9]*|*ums[0-9]*|*sprd*) HSIN_SOC_VENDOR="unisoc"; HSIN_SOC_MODEL="$_compat" ;;
		esac
	fi

	if [ "$HSIN_SOC_VENDOR" = "unknown" ] && [ -f "$(hsin_syspath /proc/cpuinfo)" ]; then
		_hw="$(grep -m1 '^Hardware' "$(hsin_syspath /proc/cpuinfo)" 2>/dev/null | cut -d: -f2 | sed 's/^[[:space:]]*//')"
		case "$_hw" in
			*Unisoc*|*SP*|*UMS*|*sprd*|*SC9*|*SC7*|*T6*|*T7*) HSIN_SOC_VENDOR="unisoc"; HSIN_SOC_MODEL="$_hw" ;;
		esac
	fi

	if [ "$HSIN_SOC_VENDOR" = "unknown" ]; then
		for _p in ro.soc.model ro.board.platform ro.hardware ro.soc.manufacturer; do
			_v="$(getprop "$_p" 2>/dev/null)"
			[ -z "$_v" ] && continue
			case "$_v" in
				*unisoc*|*sp[0-9]*|*ums[0-9]*) HSIN_SOC_VENDOR="unisoc"; ;;
			esac
			[ "$HSIN_SOC_VENDOR" != "unknown" ] && { HSIN_SOC_MODEL="$_v"; break; }
		done
	fi

	if [ "$HSIN_SOC_VENDOR" = "unknown" ] && [ -f "$(hsin_syspath /sys/devices/soc0/soc_id)" ]; then
		_v="$(_hsin_read /sys/devices/soc0/soc_id)"
		case "$_v" in
			*unisoc*|*sp*|*ums*) HSIN_SOC_VENDOR="unisoc" ;;
		esac
	fi
	export HSIN_SOC_VENDOR HSIN_SOC_MODEL
}

hsin_detect_gpu() {
	HSIN_GPU_VENDOR="unknown"
	HSIN_GPU_MODEL="unknown"
	HSIN_GPU_IFACE="none"

	if [ "$HSIN_GPU_VENDOR" = "unknown" ]; then
		_g="$(ls "$(hsin_syspath /sys/class/devfreq)" 2>/dev/null | grep -iE '\.gpu$|gpu|mali' | head -n 1)"
		if [ -n "$_g" ]; then
			HSIN_GPU_IFACE="devfreq"
			case "$_g" in
				*mali*) HSIN_GPU_VENDOR="mali" ;;
				*) HSIN_GPU_VENDOR="unknown" ;;
			esac
			HSIN_GPU_MODEL="$_g"
		fi
	fi
	export HSIN_GPU_VENDOR HSIN_GPU_IFACE HSIN_GPU_MODEL
}

hsin_detect_kernel() { HSIN_KERNEL="$(uname -r 2>/dev/null)"; export HSIN_KERNEL; }
hsin_detect_android() {
	HSIN_ANDROID_SDK="$(getprop ro.build.version.sdk 2>/dev/null)"
	HSIN_ANDROID_REL="$(getprop ro.build.version.release 2>/dev/null)"
	export HSIN_ANDROID_SDK HSIN_ANDROID_REL
}
hsin_detect_abi() { HSIN_ABI="$(getprop ro.product.cpu.abi 2>/dev/null)"; export HSIN_ABI; }

hsin_detect_topology() {
	HSIN_POLICIES=""
	HSIN_GOVERNORS=""
	for _p in $(ls -d "$(hsin_syspath /sys/devices/system/cpu/cpufreq)"/policy* 2>/dev/null); do
		[ -d "$_p" ] || continue
		HSIN_POLICIES="$HSIN_POLICIES $(basename "$_p")"
		if [ -f "$_p/scaling_available_governors" ]; then
			for _g in $(cat "$_p/scaling_available_governors" 2>/dev/null); do
				case " $HSIN_GOVERNORS " in *" $_g "*) ;; *) HSIN_GOVERNORS="$HSIN_GOVERNORS $_g" ;; esac
			done
		fi
	done
	HSIN_POLICIES="$(echo $HSIN_POLICIES | sed 's/^ //')"
	HSIN_GOVERNORS="$(echo $HSIN_GOVERNORS | sed 's/^ //')"
	export HSIN_POLICIES HSIN_GOVERNORS
}

hsin_detect_all() {
	hsin_detect_soc
	hsin_detect_gpu
	hsin_detect_kernel
	hsin_detect_android
	hsin_detect_abi
	hsin_detect_topology
}

hsin_cap_unisoc() {
	hsin_cap_node /sys/module/battery_saver/parameters/enabled || \
	[ "$HSIN_SOC_VENDOR" = "unisoc" ]
}
hsin_cap_devfreq_gpu() {
	ls "$(hsin_syspath /sys/class/devfreq)" 2>/dev/null | grep -qiE '\.gpu$|gpu|mali'
}
hsin_cap_thermal_zones() { hsin_cap_glob_dir /sys/class/thermal 'thermal_zone'; }
hsin_cap_stune()  { hsin_cap_node /dev/stune/top-app/schedtune.boost; }
hsin_cap_cpuset() { hsin_cap_node /dev/cpuset/top-app/tasks; }
hsin_cap_resetprop() { hsin_cap_cmd resetprop; }
hsin_cap_surfaceflinger() { hsin_cap_cmd service; }

hsin_profile_print() {
	echo "SOC_VENDOR : $HSIN_SOC_VENDOR"
	echo "SOC_MODEL  : $HSIN_SOC_MODEL"
	echo "GPU_VENDOR : $HSIN_GPU_VENDOR"
	echo "GPU_MODEL  : $HSIN_GPU_MODEL"
	echo "GPU_IFACE  : $HSIN_GPU_IFACE"
	echo "KERNEL     : $HSIN_KERNEL"
	echo "ANDROID    : $HSIN_ANDROID_REL (SDK $HSIN_ANDROID_SDK)"
	echo "ABI        : $HSIN_ABI"
	echo "POLICIES   : $HSIN_POLICIES"
	echo "GOVERNORS  : $HSIN_GOVERNORS"
	echo "CAP_UNISOC : $(hsin_cap_unisoc && echo yes || echo no)"
	echo "CAP_DEVF_GPU: $(hsin_cap_devfreq_gpu && echo yes || echo no)"
	echo "CAP_THERMAL: $(hsin_cap_thermal_zones && echo yes || echo no)"
	echo "CAP_STUNE  : $(hsin_cap_stune && echo yes || echo no)"
	echo "CAP_CPUSET : $(hsin_cap_cpuset && echo yes || echo no)"
	echo "CAP_PROP   : $(hsin_cap_resetprop && echo yes || echo no)"
}

HSIN_DETECT_LOADED=1
