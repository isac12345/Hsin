#!/system/bin/sh

_DISP_DIR="$(cd "$(dirname "$0")" 2>/dev/null && pwd)"
_DISP_MODDIR="${MODDIR:-$(cd "$_DISP_DIR/.." 2>/dev/null && pwd)}"

_HSIN_VDIR="unisoc"
_hs_log_msg="vendor hardcoded to 'unisoc'"

_HSIN_LOCK_FILE="$_DISP_MODDIR/backend/.vendor_lock"
if [ -f "$_HSIN_LOCK_FILE" ]; then
	_locked="$(tr -d '[:space:]' < "$_HSIN_LOCK_FILE")"
	if [ "$_locked" != "unisoc" ]; then
		hsin_log "dispatcher" "WARN: vendor_lock='$_locked' ignored, forcing 'unisoc'"
	fi
fi

_HSIN_VDIR="unisoc"
_hs_log_msg="vendor_lock active: forced 'unisoc'"

hsin_log "dispatcher" "$_hs_log_msg"

_HSIN_VDIR="$(echo "$_HSIN_VDIR" | tr '[:upper:]' '[:lower:]')"

_HSIN_VENDOR_BASE="$_DISP_MODDIR/backend/vendors/$_HSIN_VDIR"

if [ ! -d "$_HSIN_VENDOR_BASE" ]; then
	hsin_log "dispatcher" \
		"ERROR: vendor dir '$_HSIN_VENDOR_BASE' not found"
	_HSIN_VENDOR_BASE="$_DISP_MODDIR/backend/vendors/unisoc"
fi

hsin_log "dispatcher" \
	"loading vendor=$_HSIN_VDIR from $_HSIN_VENDOR_BASE"

export _HSIN_VDIR
export _HSIN_VENDOR_BASE

for _cat in cpu gpu memory io thermal render gaming refresh oom spoof; do
	_vf="$_HSIN_VENDOR_BASE/$_cat.sh"
	if [ -f "$_vf" ]; then
		. "$_vf"
	else
		hsin_log "dispatcher" "WARN missing $_vf — category $_cat unavailable"
	fi
done

HSIN_PROGRESS_FILE="${HSIN_PROGRESS_FILE:-}"
HSIN_TOTAL_FEATURES="${HSIN_TOTAL_FEATURES:-7}"

hsin_write_progress() {
	_feature="$1"; _done="${2:-0}"
	_pct="$(( (_done * 100) / ${HSIN_TOTAL_FEATURES:-7} ))"
	[ -n "$HSIN_PROGRESS_FILE" ] || return 0
	echo "${_done}/${HSIN_TOTAL_FEATURES}|${_feature}|${_pct}" \
		> "$HSIN_PROGRESS_FILE" 2>/dev/null
}

_hs_feature_start()   {
	date +%s%3N 2>/dev/null || date +%s 2>/dev/null || echo 0
}
_hs_feature_elapsed() {
	_start="$1"
	_now=$(_hs_feature_start)
	echo $((_now - _start))
}

hsin_apply_all() {
	_mode="${1:-balanced}"

	[ "${_HSIN_DETECTED:-0}" = "1" ] || { hsin_detect_all; _HSIN_DETECTED=1; }

	hsin_log "profile" \
		"START mode=$_mode soc=$HSIN_SOC_VENDOR gpu=$HSIN_GPU_VENDOR kernel=$HSIN_KERNEL"

	_feat_n=0

	_t0=$(_hs_feature_start)
	hsin_cpu_apply "$_mode"
	hsin_log "TIMING" "CPU apply $(( $(_hs_feature_start) - _t0 ))ms"
	_feat_n=$((_feat_n+1)); hsin_write_progress "CPU" "$_feat_n"

	_t0=$(_hs_feature_start)
	hsin_gpu_apply "$_mode"
	hsin_log "TIMING" "GPU apply $(( $(_hs_feature_start) - _t0 ))ms"
	_feat_n=$((_feat_n+1)); hsin_write_progress "GPU" "$_feat_n"

	_t0=$(_hs_feature_start)
	hsin_memory_apply "$_mode"
	hsin_log "TIMING" "Memory apply $(( $(_hs_feature_start) - _t0 ))ms"
	_feat_n=$((_feat_n+1)); hsin_write_progress "Memory" "$_feat_n"

	_t0=$(_hs_feature_start)
	hsin_io_apply "$_mode"
	hsin_log "TIMING" "I/O apply $(( $(_hs_feature_start) - _t0 ))ms"
	_feat_n=$((_feat_n+1)); hsin_write_progress "I/O" "$_feat_n"

	_t0=$(_hs_feature_start)
	hsin_thermal_apply "$_mode"
	hsin_log "TIMING" "Thermal apply $(( $(_hs_feature_start) - _t0 ))ms"
	_feat_n=$((_feat_n+1)); hsin_write_progress "Thermal" "$_feat_n"

	_t0=$(_hs_feature_start)
	hsin_render_apply "$_mode"
	hsin_log "TIMING" "Render apply $(( $(_hs_feature_start) - _t0 ))ms"
	_feat_n=$((_feat_n+1)); hsin_write_progress "Render" "$_feat_n"

	_t0=$(_hs_feature_start)
	hsin_gaming_apply "$_mode"
	hsin_log "TIMING" "Gaming apply $(( $(_hs_feature_start) - _t0 ))ms"
	_feat_n=$((_feat_n+1)); hsin_write_progress "Gaming" "$_feat_n"

	hsin_log "profile" "DONE mode=$_mode"
	hsin_log_flush
}

hsin_verify_all_features() {
	hsin_cpu_verify; hsin_gpu_verify; hsin_memory_verify
	hsin_io_verify;  hsin_thermal_verify; hsin_gaming_verify
}
hsin_rollback_all_features() {
	hsin_cpu_rollback; hsin_gpu_rollback; hsin_memory_rollback
	hsin_io_rollback;  hsin_thermal_rollback; hsin_gaming_rollback
}

HSIN_DISPATCHER_LOADED=1
