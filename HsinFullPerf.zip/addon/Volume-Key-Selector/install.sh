chmod -R 0755 $MODPATH/addon/Volume-Key-Selector/tools

chooseport_legacy() {
    [ "$1" ] && local delay=$1 || local delay=60
    local error=false
    while true; do
        timeout 0 $MODPATH/addon/Volume-Key-Selector/tools/$ARCH32/keycheck
        timeout $delay $MODPATH/addon/Volume-Key-Selector/tools/$ARCH32/keycheck
        local sel=$?
        if [ $sel -eq 42 ]; then
            return 0
        elif [ $sel -eq 41 ]; then
            return 1
        elif $error; then
            abort "Error!"
        else
            error=true
            echo "Try again!"
        fi
    done
}

chooseport() {
    [ "$1" ] && local delay=$1 || local delay=60
    local error=false 
    while true; do
        local count=0
        while true; do
            timeout $delay /system/bin/getevent -lqc 1 2>&1 > $TMPDIR/events &
            sleep 0.5; count=$((count + 1))
            if (`grep -q 'KEY_VOLUMEUP *DOWN' $TMPDIR/events`); then
                return 0
            elif (`grep -q 'KEY_VOLUMEDOWN *DOWN' $TMPDIR/events`); then
                return 1
            fi
            [ $count -gt 60 ] && break
        done
        if $error; then
            echo "Trying keycheck method..."
            export chooseport=chooseport_legacy VKSEL=chooseport_legacy
            chooseport_legacy $delay
            return $?
        else
            error=true
            echo "Volume key not detected, try again!"
        fi
    done
}

VKSEL=chooseport

ui_print "" 
ui_print "  Volume Key Selector to select options:"
ui_print "    1. Vulkan Only"
ui_print "    2. Skip"
ui_print ""
ui_print "  Button Function:"
ui_print "  • Volume + (Next)"
ui_print "  • Volume - (Select)"
ui_print ""

CHOICE=1
while true; do
  case $CHOICE in
    1) LABEL1="Vulkan Only" ;;
    2) LABEL1="Skip" ;;
  esac

  ui_print ""
  ui_print "Select your setting using volume keys:"
  ui_print "Current: $LABEL1"
  ui_print "Press Vol UP = Next, Vol DOWN = Select"

  if $VKSEL; then
    CHOICE=$((CHOICE + 1))
    [ $CHOICE -gt 2 ] && CHOICE=1
  else
    break
  fi
done

echo $CHOICE > $MODPATH/.selected_option

ui_print ""
ui_print "You selected: $LABEL1"
