#!/system/bin/sh

MODDIR="$(cd "$(dirname "$0")/.." && pwd)"
LOG="$MODDIR/hsin.log"

. "$MODDIR/lib/hsin_common.sh" 2>/dev/null

if [ "$(id -u)" -ne 0 ]; then
	hsin_fail "tweak3" "requires root permissions"
	exit 1
fi

apply() {
    target="$2"
    [ -f "$target" ] || return 1
    chmod 644 "$target" >/dev/null 2>&1
    if [ -w "$target" ]; then
        { echo "$1" > "$target"; } 2>/dev/null
    fi
}

for _d in /sys/block/*; do
    _n=$(basename "$_d")
    case "$_n" in loop*|ram*|zram*|dm-*|pmem*) continue ;; esac
    [ -f "$_d/queue/scheduler" ] || continue
    _avail=$(cat "$_d/queue/scheduler" 2>/dev/null)
    _sched_ok=1
    case "$_avail" in
        *mq-deadline*) apply mq-deadline "$_d/queue/scheduler" ;;
        *deadline*)    apply deadline    "$_d/queue/scheduler" ;;
        *cfq*)         apply cfq         "$_d/queue/scheduler" ;;
        *)
            hsin_skip "tweak3" "$_n no selectable scheduler (virtual device)"
            _sched_ok=0
            ;;
    esac

    apply 128 "$_d/queue/read_ahead_kb"
    apply 64  "$_d/queue/nr_requests"
    _nr_after=$(cat "$_d/queue/nr_requests" 2>/dev/null)

    if [ "$_sched_ok" = "1" ] && [ "$_nr_after" = "64" ]; then
        hsin_ok "tweak3" "I/O tuning applied for $_n"
    else
        hsin_warn "tweak3" "I/O tuning partial for $_n (nr_requests locked at $_nr_after)"
    fi
done
