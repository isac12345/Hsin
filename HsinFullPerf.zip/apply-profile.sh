#!/system/bin/sh

MODDIR="${0%/*}"
[ -z "$MODDIR" ] && MODDIR="$(cd "$(dirname "$0")" && pwd)"

PROFILE="${1:-}"
JOB_ID="${2:-}"

EXEC_TIMEOUT_SEC=30

STATUS_FILE="$MODDIR/.profile_status"
LOG="$MODDIR/hsin.log"
UI_LOG="$MODDIR/hsin_ui.log"
FEATURE_STATUS="$MODDIR/.feature_status"
PROGRESS_FILE="$MODDIR/.progress"
ROLLBACK_DIR="$MODDIR/.rollback"
DEDUP_FILE="$MODDIR/.apply_dedup"
PID_FILE="$MODDIR/.job_pid"

TOTAL_FEATURES=7

case "$PROFILE" in
	performance|balanced|battery) ;;
	*) echo "Usage: $0 <performance|balanced|battery> <job_id>" >&2; exit 1 ;;
esac
[ -z "$JOB_ID" ] && JOB_ID="job_$(date +%s)_$$"

now_ts() { date +%s 2>/dev/null || echo 0; }

write_status() {
	_phase="$1"; _ok="${2:-0}"; _partial="${3:-0}"; _skip="${4:-0}"; _fail="${5:-0}"
	_elapsed="${6:-0}"; _warn="${7:-0}"; _total="${8:-0}"; _done="${9:-0}"
	_vt="${10:-0}"; _vr="${11:-none}"; _at="${12:-0}"; _features="${13:-}"
	_unsup="${14:-0}"; _crit="${15:-0}"; _opt="${16:-0}"
	printf '%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s' \
		"$JOB_ID" "$PROFILE" "$_phase" "$_ok" "$_partial" "$_skip" "$_fail" \
		"$_elapsed" "$_warn" "$_total" "$_done" "$_vt" "$_vr" "$_at" "$_features" \
		"$_unsup" "$_crit" "$_opt" \
		> "$STATUS_FILE" 2>/dev/null
}

write_progress() {
	_feature="$1"; _done="${2:-0}"
	echo "$_feature" > "$PROGRESS_FILE" 2>/dev/null
	echo "${_done}/${TOTAL_FEATURES}|${_feature}" >> "$MODDIR/.progress_log" 2>/dev/null
}

log_msg() {
	echo "$(date +%H:%M:%S) [ApplyProfile] $1" >> "$LOG" 2>/dev/null
}

is_current_job() {
	_cur_id="$(sed -n '1p' "$STATUS_FILE" 2>/dev/null | cut -d'|' -f1)"
	[ "$_cur_id" = "$JOB_ID" ]
}

START_TS=$(now_ts)

if [ -f "$PID_FILE" ]; then
	_prev="$(cat "$PID_FILE" 2>/dev/null)"
	_prev_job="${_prev%%|*}"
	_prev_pid="${_prev##*|}"
	if [ -n "$_prev_pid" ] && [ "$_prev_job" != "$JOB_ID" ] && kill -0 "$_prev_pid" 2>/dev/null; then
		kill -TERM "$_prev_pid" 2>/dev/null
		log_msg "job=$JOB_ID preempted previous job=$_prev_job (pid=$_prev_pid)"
	fi
fi

_CANCELLED=0
_cleanup() {
	if is_current_job; then
		write_status "cancelled" 0 0 0 0 "$(($(now_ts) - START_TS))"
		log_msg "job=$JOB_ID cancelled (signal)"
	fi
	_CANCELLED=1
}
trap _cleanup TERM INT
PROFILE_SCRIPT="$MODDIR/profile/$PROFILE"

if [ ! -f "$PROFILE_SCRIPT" ]; then
	write_status "failed" 0 0 0 1 0 0 "$TOTAL_FEATURES" 0
	log_msg "job=$JOB_ID FAILED: profile script not found: $PROFILE_SCRIPT"
	exit 1
fi

: > "$PROGRESS_FILE" 2>/dev/null
: > "$MODDIR/.progress_log" 2>/dev/null
: > "$DEDUP_FILE" 2>/dev/null

write_status "applying" 0 0 0 0 0 0 "$TOTAL_FEATURES" 0
log_msg "job=$JOB_ID START profile=$PROFILE"

export HSIN_JOB_ID="$JOB_ID"
export HSIN_PROFILE_STATUS_FILE="$STATUS_FILE"
export HSIN_PROGRESS_FILE="$PROGRESS_FILE"
export HSIN_TOTAL_FEATURES="$TOTAL_FEATURES"
export HSIN_DEDUP_FILE="$DEDUP_FILE"

_LOG_LINES_BEFORE=$(wc -l < "$LOG" 2>/dev/null)
_LOG_LINES_BEFORE=${_LOG_LINES_BEFORE:-0}

log_msg "job=$JOB_ID executing profile (timeout=${EXEC_TIMEOUT_SEC}s)"

sh "$PROFILE_SCRIPT" "" "$PROFILE" 2>/dev/null &
_PROFILE_PID=$!
echo "$JOB_ID|$_PROFILE_PID" > "$PID_FILE" 2>/dev/null
elapsed=0
_rc=0
while kill -0 "$_PROFILE_PID" 2>/dev/null; do
	if [ "$elapsed" -ge "$EXEC_TIMEOUT_SEC" ]; then
		kill -TERM "$_PROFILE_PID" 2>/dev/null
		_rc=124
		break
	fi
	sleep 1
	elapsed=$((elapsed + 1))
done
if [ "$_rc" -ne 124 ]; then
	wait "$_PROFILE_PID" 2>/dev/null
	_rc=$?
fi

if ! is_current_job; then
	log_msg "job=$JOB_ID superseded by new job, exiting"
	exit 0
fi

APPLY_ELAPSED=$(($(now_ts) - START_TS))

if [ "$_rc" -eq 124 ]; then
	write_status "timeout" 0 0 0 1 "$APPLY_ELAPSED" 0 "$TOTAL_FEATURES" "$TOTAL_FEATURES" 0 "none" "$APPLY_ELAPSED"
	log_msg "job=$JOB_ID TIMEOUT after ${EXEC_TIMEOUT_SEC}s"
	exit 1
fi

_ok=0; _partial=0; _skip=0; _fail=0; _warn=0; _unsup=0; _critical=0; _optional=0

_LOG_LINES_NEW=$(tail -n "+$((_LOG_LINES_BEFORE + 1))" "$LOG" 2>/dev/null)

_ok=$(echo "$_LOG_LINES_NEW" | grep -c "\[OK\]")
_ok=${_ok:-0}
_skip=$(echo "$_LOG_LINES_NEW" | grep -c "\[SKIP\]")
_skip=${_skip:-0}
_fail=$(echo "$_LOG_LINES_NEW" | grep -c "\[FAIL\]")
_fail=${_fail:-0}
_warn=$(echo "$_LOG_LINES_NEW" | grep -c "\[WARN\]")
_warn=${_warn:-0}
_unsup=$(echo "$_LOG_LINES_NEW" | grep -c "\[UNSUPPORTED\]")
_unsup=${_unsup:-0}
_partial=$(echo "$_LOG_LINES_NEW" | grep -c "requested=.*after=")
_partial=${_partial:-0}

_critical=$(echo "$_LOG_LINES_NEW" | grep "\[FAIL\]" | grep -c "scaling_governor\|scaling_min_freq\|scaling_max_freq\|dirty_ratio\|dirty_background")
_critical=${_critical:-0}
_optional=$((_fail - _critical))
[ "$_optional" -lt 0 ] && _optional=0

_features_done=0
if [ -f "$FEATURE_STATUS" ]; then
	_features_done=$(wc -l < "$FEATURE_STATUS" 2>/dev/null)
	_features_done=${_features_done:-0}
fi

_feature_lines=""
if [ -f "$FEATURE_STATUS" ]; then
	_feature_lines=$(cat "$FEATURE_STATUS" 2>/dev/null)
fi

if [ "$_critical" -gt 0 ]; then
	_final="failed"
elif [ "$_fail" -gt 0 ] || [ "$_partial" -gt 0 ]; then
	_final="partial"
elif [ "$_ok" -eq 0 ] && [ "$_skip" -gt 0 ]; then
	_final="applied"
else
	_final="applied"
fi

if [ "$_rc" -ne 0 ] && [ "$_rc" -ne 124 ] && [ "$_ok" -gt 0 ] && [ "$_critical" -eq 0 ]; then
	log_msg "job=$JOB_ID rc=$_rc but $_ok tweaks applied successfully (non-critical)"
fi

write_status "$_final" "$_ok" "$_partial" "$_skip" "$_fail" "$APPLY_ELAPSED" "$_warn" "$TOTAL_FEATURES" "$_features_done" 0 "none" "$APPLY_ELAPSED" "" "$_unsup" "$_critical" "$_optional"
log_msg "job=$JOB_ID FINAL: $_final ok=$_ok partial=$_partial skip=$_skip unsup=$_unsup warn=$_warn fail=$_fail critical=$_critical optional=$_optional elapsed=${APPLY_ELAPSED}s features=$_features_done/$TOTAL_FEATURES"

_ts=$(date '+%H:%M:%S')
{
	echo "[${_ts}] Profile ${PROFILE} applied"
	if [ -n "$_feature_lines" ]; then
		echo "$_feature_lines" | while IFS='|' read -r _fname _fstatus _fapplied _fskipped _ferr _funsup _fcrit _fdur; do
			case "$_fstatus" in
				applied) echo "✓ ${_fname} ${_fdur}s" ;;
				warning) echo "⚠ ${_fname} ${_fdur}s" ;;
				skipped) echo "— ${_fname}" ;;
				error)   echo "✗ ${_fname} ${_fdur}s" ;;
			esac
		done
	fi
	echo "${_ok} applied • ${_skip} skipped • ${_unsup} unsupported • ${_fail} errors"
	echo ""
} >> "$UI_LOG" 2>/dev/null

if [ "$_final" = "applied" ] || [ "$_final" = "partial" ]; then
	echo "$PROFILE" > "$MODDIR/.current_mode" 2>/dev/null
	{
		echo "profile=$PROFILE"
		echo "status=$_final"
		echo "applied=$_ok"
		echo "skipped=$_skip"
		echo "unsupported=$_unsup"
		echo "errors=$_fail"
		echo "critical=$_critical"
		echo "optional=$_optional"
		echo "timestamp=$(date +%s 2>/dev/null || echo 0)"
		echo "apply_time=$APPLY_ELAPSED"
	} > "$MODDIR/.profile_state" 2>/dev/null
	log_msg "job=$JOB_ID persistent state saved: profile=$PROFILE status=$_final"
fi

if [ -f "$UI_LOG" ]; then
	_lines=$(wc -l < "$UI_LOG" 2>/dev/null)
	_lines=${_lines:-0}
	[ "$_lines" -gt 200 ] && tail -n 200 "$UI_LOG" > "${UI_LOG}.tmp" 2>/dev/null && mv "${UI_LOG}.tmp" "$UI_LOG" 2>/dev/null
fi

rm -f "$DEDUP_FILE" 2>/dev/null
rm -f "$PROGRESS_FILE" 2>/dev/null

_own="$(cat "$PID_FILE" 2>/dev/null)"
[ "${_own%%|*}" = "$JOB_ID" ] && rm -f "$PID_FILE" 2>/dev/null

exit 0
