#!/data/data/com.termux/files/usr/bin/bash
set -e

SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
OUT_DIR="/sdcard/modulroot"
mkdir -p "$OUT_DIR" 2>/dev/null
if [ ! -w "$OUT_DIR" ]; then
    echo "Tidak bisa nulis ke /sdcard/modulroot."
    echo "Jalankan 'termux-setup-storage' dulu sekali (izinkan akses storage saat diminta), lalu ulangi build_release.sh"
    OUT_DIR="$SRC_DIR/releases"
    mkdir -p "$OUT_DIR"
    if [ ! -w "$OUT_DIR" ]; then
        echo "Fallback juga gagal: $OUT_DIR tidak writable"
        exit 1
    fi
    echo "Fallback: pakai $OUT_DIR"
fi
VERSION="${1:-v1-Alpha}"

mkdir -p "$OUT_DIR"

strip_comments_from_build() {
    _target="$1"

    python3 - "$_target" <<'PYEOF'
import re, sys, glob, os

root = sys.argv[1]

def strip_shell(path):
    lines = open(path, encoding='utf-8', errors='replace').read().split("\n")
    out = []
    heredoc_term = None
    strip_tabs = False
    for i, line in enumerate(lines):
        if heredoc_term is not None:
            out.append(line)
            check = line.lstrip('\t') if strip_tabs else line
            if check == heredoc_term:
                heredoc_term = None
            continue
        m = re.search(r'<<-?\s*([\'"]?)(\w+)\1', line)
        if m:
            strip_tabs = '<<-' in line
            heredoc_term = m.group(2)
            out.append(line)
            continue
        s = line.lstrip()
        if i == 0 and s.startswith('#!'):
            out.append(line); continue
        if s.startswith('#'):
            continue
        out.append(line)
    text = re.sub(r'\n{3,}', '\n\n', "\n".join(out))
    open(path, 'w', encoding='utf-8').write(text)

def strip_js(path):
    lines = open(path, encoding='utf-8', errors='replace').read().split("\n")
    out = []; in_block = False
    for line in lines:
        s = line.strip()
        if in_block:
            if '*/' in s: in_block = False
            continue
        if s.startswith('/*'):
            if '*/' not in s: in_block = True
            continue
        if s.startswith('//'):
            continue
        out.append(line)
    text = re.sub(r'\n{3,}', '\n\n', "\n".join(out))
    open(path, 'w', encoding='utf-8').write(text)

def strip_css(path):
    text = open(path, encoding='utf-8', errors='replace').read()
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.DOTALL)
    text = re.sub(r'\n{3,}', '\n\n', text)
    open(path, 'w', encoding='utf-8').write(text)

def strip_html(path):
    text = open(path, encoding='utf-8', errors='replace').read()
    text = re.sub(r'<!--.*?-->', '', text, flags=re.DOTALL)
    text = re.sub(r'\n\s*\n\s*\n+', '\n\n', text)
    open(path, 'w', encoding='utf-8').write(text)

for dirpath, _, files in os.walk(root):
    for fn in files:
        p = os.path.join(dirpath, fn)
        if fn.endswith('.sh') or fn in ('customize.sh','uninstall.sh','service.sh','hsinctl') or dirpath.endswith('/profile'):
            strip_shell(p)
        elif fn.endswith('.js'):
            strip_js(p)
        elif fn.endswith('.css'):
            strip_css(p)
        elif fn.endswith('.html'):
            strip_html(p)
PYEOF
}

build_unisoc() {
    _build="$OUT_DIR/build_unisoc"
    rm -rf "$_build"
    mkdir -p "$_build"

    for item in "$SRC_DIR"/*; do
        _name="$(basename "$item")"
        [ "$_name" = "releases" ] && continue
        [ "$_name" = "hsin-project" ] && continue
        case "$item" in
            "$OUT_DIR/build_"*) continue ;;
        esac
        cp -r "$item" "$_build/"
    done
    for _dot in "$SRC_DIR/.current_mode" "$SRC_DIR/.profile_state"; do
        [ -f "$_dot" ] && cp -r "$_dot" "$_build/" 2>/dev/null || true
    done

    rm -rf "$_build/backend/vendors"
    rm -f "$_build/backend/hsin_features.sh.OLD_BACKUP" 2>/dev/null
    rm -f "$_build/FINAL_TEST_REPORT.log" "$_build/FINAL_TEST_REPORT.txt" "$_build/hsin.log" "$_build/hsin_ui.log" 2>/dev/null
    mkdir -p "$_build/backend/vendors/unisoc"
    cp -r "$SRC_DIR/backend/vendors/unisoc/." "$_build/backend/vendors/unisoc/"

    echo "unisoc" > "$_build/backend/.vendor_lock"

    if [ -d "$_build/Misc/tweak1.sh" ]; then rm -f "$_build/Misc/tweak1.sh" 2>/dev/null; fi
    if [ -d "$_build/Misc/tweak4.sh" ]; then rm -f "$_build/Misc/tweak4.sh" 2>/dev/null; fi
    rm -f "$_build/Misc/GameTweaks.txt" 2>/dev/null

    strip_comments_from_build "$_build"

    _syntax_fail=0
    while IFS= read -r f; do
        [ -z "$f" ] && continue
        if ! bash -n "$f" 2>/dev/null; then
            echo "SYNTAX ERROR setelah strip: $f"
            bash -n "$f" 2>&1 | head -n 20
            _syntax_fail=1
        fi
    done <<EOF
$(find "$_build" -type f \( -name "*.sh" -o -name "customize.sh" -o -name "uninstall.sh" -o -name "service.sh" -o -path "*/profile/*" \) 2>/dev/null)
EOF
    if command -v node >/dev/null 2>&1; then
        if [ -f "$_build/webroot/app.js" ]; then
            if ! node --check "$_build/webroot/app.js" 2>&1; then
                echo "SYNTAX ERROR JS setelah strip: webroot/app.js"
                node --check "$_build/webroot/app.js" 2>&1 | head -n 20
                _syntax_fail=1
            fi
        fi
    fi
    if [ "$_syntax_fail" = "1" ]; then
        echo "GAGAL: strip komentar merusak syntax, build dibatalkan."
        exit 1
    fi

    ( cd "$OUT_DIR" && zip -r -X "HSIN_${VERSION}-Unisoc.zip" "build_unisoc" -x ".*" > /dev/null )
    rm -rf "$_build"
    echo "OK -> $OUT_DIR/HSIN_${VERSION}-Unisoc.zip"
}

build_unisoc

echo ""
echo "Selesai. ZIP rilis ada di folder: $OUT_DIR"
ls -lh "$OUT_DIR"/HSIN_*.zip 2>/dev/null || ls -la "$OUT_DIR"/*.zip 2>/dev/null || echo "No zip found"
