#!/system/bin/sh

MODDIR=${0%/*}

ui_print "***************************************"
ui_print "*         Hsin WebUI v1-Alpha         *"
ui_print "*        by @CLEVERdumb               *"
ui_print "*        Build: 23-09-2026            *"
ui_print "*        Support Varians : Unisoc     *"
ui_print "***************************************"
ui_print ""

ui_print "- Device Info:"
ui_print "  Product   : $(getprop ro.build.product)"
ui_print "  Model     : $(getprop ro.product.model)"
ui_print "  Manufacturer: $(getprop ro.product.manufacturer)"
ui_print "  CPU ABI   : $(getprop ro.product.cpu.abi)"
ui_print "  Android   : $(getprop ro.build.version.release)"
ui_print "  Kernel    : $(uname -r)"
ui_print "  RAM       : $(grep MemTotal /proc/meminfo | awk '{print $2/1024" MB"}')"
ui_print ""-
sleep 1

ui_print "@CLEVERdumb"
sleep 0.5
sleep 2
ui_print ""
ui_print "==============================="
ui_print "✅ Gaming Module 🎮"

if [ "$(ls -A $MODPATH/addon/*/install.sh 2>/dev/null)" ]; then
  ui_print "- Running Addons"
  for i in $MODPATH/addon/*/install.sh; do
    ui_print "  Running $(echo $i | sed -r "s|$MODPATH/addon/(.*)/install.sh|\1|")..."
    . $i
  done
fi

  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm_recursive $MODPATH/service.sh 0 0 0755 0755
  set_perm_recursive $MODPATH/Misc 0 0 0755 0755
  set_perm_recursive $MODPATH/profile 0 0 0755 0755
  set_perm_recursive $MODPATH 0 0 0755 0644

ui_print "- Membersihkan log dan state dari versi sebelumnya"
rm -f "$MODPATH/hsin.log" 2>/dev/null
rm -f "$MODPATH/hsin_ui.log" 2>/dev/null
rm -f "$MODPATH"/diagnostic_*.txt 2>/dev/null
rm -f "$MODPATH/.feature_status" 2>/dev/null
rm -f "$MODPATH/.profile_status" 2>/dev/null
rm -f "$MODPATH/.profile_state" 2>/dev/null
rm -f "$MODPATH/.progress" 2>/dev/null
rm -f "$MODPATH/.progress_log" 2>/dev/null
rm -f "$MODPATH/.apply_dedup" 2>/dev/null
rm -f "$MODPATH/.job_pid" 2>/dev/null
rm -rf "$MODPATH/.rollback" 2>/dev/null
rm -rf "$MODPATH/.hsin_state" 2>/dev/null
ui_print "  • Log dan state lama dibersihkan"

ui_print "- Menyiapkan background kustom"
mkdir -p "$MODPATH/webroot/backgrounds"
if [ -f "$MODPATH/background.jpg" ]; then
  cp -f "$MODPATH/background.jpg" "$MODPATH/webroot/backgrounds/background.jpg" 2>/dev/null
  ui_print "  • background.jpg -> webroot/backgrounds/"
else
  if [ -f "$MODPATH/clever.png" ]; then
    cp -f "$MODPATH/clever.png" "$MODPATH/webroot/backgrounds/background.jpg" 2>/dev/null
    ui_print "  • background.jpg tidak ditemukan, buat placeholder dari clever.png"
  else
    touch "$MODPATH/webroot/backgrounds/background.jpg" 2>/dev/null
  fi
fi
if [ -f "$MODPATH/bekron.jpg" ]; then
  cp -f "$MODPATH/bekron.jpg" "$MODPATH/webroot/backgrounds/bekron.jpg" 2>/dev/null
  ui_print "  • bekron.jpg -> webroot/backgrounds/"
else
  if [ -f "$MODPATH/clever.png" ]; then
    cp -f "$MODPATH/clever.png" "$MODPATH/webroot/backgrounds/bekron.jpg" 2>/dev/null
    ui_print "  • bekron.jpg tidak ditemukan, buat placeholder dari clever.png"
  else
    touch "$MODPATH/webroot/backgrounds/bekron.jpg" 2>/dev/null
  fi
fi
ls -lh "$MODPATH/webroot/backgrounds/" 2>/dev/null | while read line; do ui_print "    $line"; done

rm -f "$MODPATH/Misc/GameTweaks.txt" 2>/dev/null

ui_print " 🌐 Hsin WebUI terpasang"
ui_print " "
