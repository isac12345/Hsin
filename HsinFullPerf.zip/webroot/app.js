
function getModDir() {
  try {
    if (typeof ksu !== "undefined" && ksu.moduleDir) return ksu.moduleDir;
    if (typeof ksu !== "undefined" && ksu.module) return "/data/adb/modules/" + ksu.module;
  } catch(e) {}
  try {
    const href = (typeof window !== "undefined" && window.location && window.location.href) || "";
    const m = href.match(/file:\/\/(\/data\/adb\/modules\/[^\/]+)/);
    if (m) return m[1];
    const p = (typeof window !== "undefined" && window.location && window.location.pathname) || "";
    const m2 = p.match(/^(\/data\/adb\/modules\/[^\/]+)/);
    if (m2) return m2[1];
  } catch(e) {}
  return "/data/adb/modules/HSIN";
}
const MODDIR = getModDir();
const DEMO_MODE = (typeof ksu === "undefined");
let _cbId = 0;

function modeIcon(mode) {
  const batterySvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="28" height="28"><rect x="2" y="7" width="16" height="10" rx="2"/><line x1="22" y1="10" x2="22" y2="14"/></svg>';
  const balancedSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="28" height="28"><line x1="12" y1="2" x2="12" y2="5"/><path d="M5 22h14"/><path d="M10 11 5 22"/><path d="M14 11 19 22"/><path d="M10 11h4"/></svg>';
  const perfSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="28" height="28"><polygon points="13,2 3,14 12,14 11,22 21,10 12,10"/></svg>';
  if (!mode) return batterySvg;
  const m = String(mode).toLowerCase().trim();
  if (m === "battery" || m.includes("baterai") || m.includes("hemat")) return batterySvg;
  if (m === "balanced" || m.includes("seimbang")) return balancedSvg;
  if (m === "performance" || m.includes("performa")) return perfSvg;
  return batterySvg;
}

const I18N = {
  id: {
    "nav.utama": "Utama",
    "nav.mode": "Mode",
    "nav.game": "Game",
    "nav.pengaturan": "Pengaturan",
    "page.utama": "Utama",
    "page.mode": "Mode",
    "page.game": "Game Saya",
    "page.pengaturan": "Pengaturan",
    "hero.neutral": "Belum ada mode diterapkan",
    "hero.neutral.sub": "Pilih mode di tab Mode untuk memulai",
    "hero.active": "AKTIF ✨",
    "hero.active.sub": "Mode: ",
    "hero.autobadge": "Diterapkan Otomatis",
    "info.version": "HSIN",
    "info.profile": "Profil Saat Ini",
    "info.kernel": "Kernel",
    "info.chipset": "Chipset",
    "info.sdk": "Android SDK",
    "section.pilih": "MODE",
    "section.kerjacerdas": "Kerja Cerdas",
    "autodesc": "Otomatis deteksi game dan aktifkan Mode Performa, kembali ke Seimbang saat keluar game",
    "auto.label": "Mode Otomatis",
    "auto.desc": "Deteksi game otomatis dan aktifkan mode yang sesuai",
    "section.monitor": "Monitor Sistem",
    "monitor.desc": "Data real-time, refresh tiap 3 detik",
    "monitor.cpu": "CPU",
    "monitor.gpu": "GPU",
    "monitor.temp": "Suhu",
    "search.placeholder": "Cari aplikasi...",
    "section.gameSaya": "GAME SAYA",
    "tp.title": "APLIKASI PIHAK KETIGA",
    "tp.desc": "Atur mode per-aplikasi non-game",
    "tp.add": "+ Tambah Aplikasi",
    "tp.follow": "Ikuti Global",
    "tp.battery": "Hemat Baterai",
    "tp.balanced": "Seimbang",
    "tp.performance": "Performa",
    "settings.tampilan": "Tampilan",
    "settings.theme": "Tema Gelap",
    "settings.theme.desc": "Ganti antara mode gelap dan terang",
    "settings.lang": "Bahasa",
    "settings.lang.desc": "Pilih bahasa antarmuka",
    "settings.info": "Informasi",
    "settings.system": "Sistem",
    "update.label": "Cek Update",
    "update.desc": "Periksa versi terbaru dari GitHub",
    "about.label": "Tentang",
    "about.desc": "Informasi detail modul",
    "log.label": "Log Sistem",
    "log.desc": "Lihat log aktivitas modul",
    "about.title": "Tentang",
    "about.name": "Nama Modul",
    "about.author": "Pembuat",
    "about.version": "Versi",
    "log.title": "Log Sistem",
    "modal.title": "Tambah Aplikasi Pihak Ketiga",
    "modal.pkg": "Package Name",
    "modal.mode": "Per-App Mode",
    "modal.cancel": "Batal",
    "modal.confirm": "Tambah",
    "toast.demo": "Mode pratinjau (tanpa KernelSU/APatch)",
    "toast.applied": "Profil diterapkan",
    "toast.failed": "Gagal menerapkan profil",
    "toast.auto.on": "Auto-Mode diaktifkan",
    "toast.auto.off": "Auto-Mode dimatikan",
    "toast.theme": "Tema diubah",
    "toast.lang": "Bahasa diubah",
    "toast.added": "Ditambahkan",
    "toast.removed": "Dihapus",
    "toast.update.nodata": "Periksa secara manual di GitHub",
    "toast.update.latest": "Sudah versi terbaru",
    "toast.update.available": "Update tersedia!",
    "toast.copied": "Tautan disalin",
    "info.section": "INFO MODUL",
    "support.title": "Dukung Pengembangan",
    "support.text": "HSIN akan selalu gratis. Dukungan Anda membantu modul ini terus dikembangkan.",
    "support.saweria": "☕ Saweria",
    "support.github": "⭐ GitHub",
    "status.live": "LIVE",
    "about.subtitle": "HSIN Gaming Module",
    "about.by": "Oleh CLEVERdumb",
    "about.desc.main": "Modul KernelSU/APatch untuk optimasi performa gaming di Android. Mendukung profil Hemat Baterai, Seimbang, dan Performa dengan deteksi otomatis game.",
    "about.desc.credit": "Open source. Kredit ke komunitas KernelSU, Magisk, dan para kontributor script tweak.",
    "log.loading": "Memuat log…",
    "settings.bg": "Background",
    "settings.bg.desc": "Pilih gambar latar",
    "bg.default": "Default",
    "bg.background": "background.jpg",
    "bg.bekron": "bekron.jpg",
    "toast.bg": "Background diubah",
    "log.warning": "⚠ Tweak gagal di baris",
    "info.notset": "Belum diatur",
    "game.active": "AKTIF",
    "empty.apps": "Tidak ada aplikasi ditemukan",
    "empty.thirdparty": "Tidak ada aplikasi pihak ketiga",
    "monitor.nodata": "Tidak ada data",
    "monitor.nogpu": "Tidak ada data GPU",
    "monitor.noterm": "Tidak ada data suhu",
    "toast.fillpkg": "Isi package name",
    "log.empty": "Log kosong",
    "profile.applying": "Menerapkan…",
    "profile.applied": "Diterapkan",
    "profile.partial": "Sebagian",
    "profile.failed": "Gagal",
    "profile.timeout": "Timeout",
    "profile.vendor.skipped": "vendor tweaks skipped",
    "log.show_details": "Show Details",
    "log.hide_details": "Hide Details",
    "log.applied": "applied",
    "log.skipped": "skipped",
    "log.errors": "errors",
    "log.unsupported": "unsupported",
    "settings.dnd": "DND saat Gaming",
    "settings.dnd.desc": "Aktifkan Do Not Disturb otomatis saat game aktif",
    "settings.powersave": "Power Save Auto",
    "settings.powersave.desc": "Otomatis ke mode Battery saat Battery Saver aktif",
    "game.state.idle": "Tidak aktif",
    "game.state.active": "Game Aktif",
    "game.state.powersave": "Power Save",
    "toast.dnd.on": "DND Gaming diaktifkan",
    "toast.dnd.off": "DND Gaming dimatikan",
  },
  en: {
    "nav.utama": "Home",
    "nav.mode": "Mode",
    "nav.game": "Games",
    "nav.pengaturan": "Settings",
    "page.utama": "Home",
    "page.mode": "Mode",
    "page.game": "My Games",
    "page.pengaturan": "Settings",
    "hero.neutral": "No mode applied yet",
    "hero.neutral.sub": "Pick a mode in the Mode tab to start",
    "hero.active": "ACTIVE ✨",
    "hero.active.sub": "Mode: ",
    "hero.autobadge": "Applied Automatically",
    "info.version": "HSIN",
    "info.profile": "Current Profile",
    "info.kernel": "Kernel",
    "info.chipset": "Chipset",
    "info.sdk": "Android SDK",
    "section.pilih": "MODE",
    "section.kerjacerdas": "Smart Work",
    "autodesc": "Auto-detect games and enable Performance Mode, revert to Balanced when leaving game",
    "auto.label": "Auto Mode",
    "auto.desc": "Auto-detect games and apply the right mode",
    "section.monitor": "System Monitor",
    "monitor.desc": "Real-time data, refreshes every 3s",
    "monitor.cpu": "CPU",
    "monitor.gpu": "GPU",
    "monitor.temp": "Temperature",
    "search.placeholder": "Search apps...",
    "section.gameSaya": "MY GAMES",
    "tp.title": "THIRD-PARTY APPS",
    "tp.desc": "Set per-app mode for non-game apps",
    "tp.add": "+ Add App",
    "tp.follow": "Follow Global",
    "tp.battery": "Battery Saver",
    "tp.balanced": "Balanced",
    "tp.performance": "Performance",
    "settings.tampilan": "Appearance",
    "settings.theme": "Dark Theme",
    "settings.theme.desc": "Toggle dark / light mode",
    "settings.lang": "Language",
    "settings.lang.desc": "Choose interface language",
    "settings.info": "Information",
    "settings.system": "System",
    "update.label": "Check Update",
    "update.desc": "Check latest version from GitHub",
    "about.label": "About",
    "about.desc": "Module details",
    "log.label": "System Log",
    "log.desc": "View module activity log",
    "about.title": "About",
    "about.name": "Module Name",
    "about.author": "Author",
    "about.version": "Version",
    "log.title": "System Log",
    "modal.title": "Add Third-Party App",
    "modal.pkg": "Package Name",
    "modal.mode": "Per-App Mode",
    "modal.cancel": "Cancel",
    "modal.confirm": "Add",
    "toast.demo": "Preview mode (no KernelSU/APatch)",
    "toast.applied": "Profile applied",
    "toast.failed": "Failed to apply profile",
    "toast.auto.on": "Auto-Mode enabled",
    "toast.auto.off": "Auto-Mode disabled",
    "toast.theme": "Theme changed",
    "toast.lang": "Language changed",
    "toast.added": "Added",
    "toast.removed": "Removed",
    "toast.update.nodata": "Check manually on GitHub",
    "toast.update.latest": "Already latest version",
    "toast.update.available": "Update available!",
    "toast.copied": "Link copied",
    "info.section": "INFO MODULE",
    "support.title": "Support Development",
    "support.text": "HSIN will always be free. Your support helps keep it improving.",
    "support.saweria": "☕ Saweria",
    "support.github": "⭐ GitHub",
    "status.live": "LIVE",
    "about.subtitle": "HSIN Gaming Module",
    "about.by": "By CLEVERdumb",
    "about.desc.main": "KernelSU/APatch module for gaming performance optimization on Android. Supports Battery Saver, Balanced and Performance profiles with automatic game detection.",
    "about.desc.credit": "Open source. Credit to the KernelSU, Magisk community and tweak script contributors.",
    "log.loading": "Loading log…",
    "settings.bg": "Background",
    "settings.bg.desc": "Choose background image",
    "bg.default": "Default",
    "bg.background": "background.jpg",
    "bg.bekron": "bekron.jpg",
    "toast.bg": "Background changed",
    "log.warning": "⚠ Tweak failed at line",
    "info.notset": "Not set",
    "game.active": "ACTIVE",
    "empty.apps": "No apps found",
    "empty.thirdparty": "No third-party apps",
    "monitor.nodata": "No data",
    "monitor.nogpu": "No GPU data",
    "monitor.noterm": "No thermal data",
    "toast.fillpkg": "Enter package name",
    "log.empty": "Log empty",
    "profile.applying": "Applying…",
    "profile.applied": "Applied",
    "profile.partial": "Partial",
    "profile.failed": "Failed",
    "profile.timeout": "Timeout",
    "profile.vendor.skipped": "vendor tweaks skipped",
    "log.show_details": "Show Details",
    "log.hide_details": "Hide Details",
    "log.applied": "applied",
    "log.skipped": "skipped",
    "log.errors": "errors",
    "log.unsupported": "unsupported",
    "settings.dnd": "DND While Gaming",
    "settings.dnd.desc": "Auto-enable Do Not Disturb when game is active",
    "settings.powersave": "Power Save Auto",
    "settings.powersave.desc": "Auto-switch to Battery mode when Battery Saver is active",
    "game.state.idle": "Inactive",
    "game.state.active": "Game Active",
    "game.state.powersave": "Power Save",
    "toast.dnd.on": "DND Gaming enabled",
    "toast.dnd.off": "DND Gaming disabled",
  }
};

let currentLang = (typeof localStorage !== "undefined" && localStorage.getItem("hsin_lang")) || "id";
let currentTheme = (typeof localStorage !== "undefined" && localStorage.getItem("hsin_theme")) || "dark";

function t(key) {
  const dict = I18N[currentLang] || I18N.id;
  return dict[key] || I18N.id[key] || key;
}

function applyI18n() {
  document.querySelectorAll("[data-i18n]").forEach(el => {
    const key = el.getAttribute("data-i18n");
    if (el.id === "log-content") {
      const cur = el.textContent.trim();
      const isPlaceholder = cur === "Memuat log\u2026" || cur === "Loading log\u2026" || cur === t("log.loading") || cur === "Memuat log…" || cur === "Loading log…";
      if (!isPlaceholder && cur !== "" && cur !== "Log kosong" && cur !== t("log.empty") && !cur.startsWith("Demo log")) {
        return;
      }
    }
    el.textContent = t(key);
  });
  document.querySelectorAll("[data-i18n-ph]").forEach(el => {
    const key = el.getAttribute("data-i18n-ph");
    el.setAttribute("placeholder", t(key));
  });
  document.querySelectorAll("[data-i18n-title]").forEach(el => {
    const key = el.getAttribute("data-i18n-title");
    el.setAttribute("title", t(key));
  });
}

function savePref(key, val) {
  try { localStorage.setItem(key, val); } catch (e) {}
  if (!DEMO_MODE) {
    run(`{ echo '${val}' > ${MODDIR}/.pref_${key}; } 2>/dev/null`);
  }
}
function loadPref(key) {
  try {
    const v = localStorage.getItem(key);
    if (v !== null) return v;
  } catch (e) {}
  return null;
}

function toast(msg) {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.classList.remove("hidden");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.add("hidden"), 2200);
}

function run(cmd) {
  return new Promise((resolve) => {
    if (DEMO_MODE) {
      resolve({ errno: 0, stdout: "", stderr: "" });
      return;
    }
    const cb = "__hsin_cb_" + (_cbId++);
    window[cb] = (errno, stdout, stderr) => {
      delete window[cb];
      resolve({ errno, stdout: stdout || "", stderr: stderr || "" });
    };
    try {
      ksu.exec(cmd, "{}", cb);
    } catch (e) {
      resolve({ errno: -1, stdout: "", stderr: String(e) });
    }
  });
}

function switchPage(name) {
  document.querySelectorAll(".page").forEach(p => p.classList.add("hidden"));
  const target = document.getElementById("page-" + name);
  if (target) {
    target.classList.remove("hidden");
    target.style.animation = "none";
    void target.offsetHeight;
    target.style.animation = "";
  }

  document.querySelectorAll(".nav-item").forEach(b => {
    b.classList.toggle("active", b.dataset.page === name);
  });

  if (name !== "mode") stopMonitor();
  if (name !== "utama") stopAutoStatus();

  if (name === "utama") { loadBeranda(); startAutoStatus(); }
  if (name === "mode") { loadMode(); startMonitor(); }
  if (name === "game") loadGameList();
}

document.querySelectorAll(".nav-item").forEach(btn => {
  btn.addEventListener("click", () => switchPage(btn.dataset.page));
});

function openSubPage(id) {
  document.querySelectorAll(".page").forEach(p => p.classList.add("hidden"));
  document.getElementById("page-" + id).classList.remove("hidden");
  document.querySelectorAll(".nav-item").forEach(b => b.classList.remove("active"));
}
function closeSubPage() {
  switchPage("pengaturan");
}

document.getElementById("btn-back-from-log")?.addEventListener("click", closeSubPage);
document.getElementById("btn-back-from-about")?.addEventListener("click", closeSubPage);

async function detectActiveProfile() {
  if (DEMO_MODE) return DEMO_STATE.currentMode;

  const stateRes = await run(`cat ${MODDIR}/.profile_state 2>/dev/null`);
  const stateRaw = (stateRes.stdout || "").trim();
  if (stateRaw) {
    const stateLines = stateRaw.split("\n");
    const stateMap = {};
    stateLines.forEach(line => {
      const [k, ...v] = line.split("=");
      if (k) stateMap[k.trim()] = v.join("=").trim();
    });
    const fileMode = stateMap.profile || "";
    const fileStatus = stateMap.status || "";
    if (fileMode && ["performance", "balanced", "battery"].includes(fileMode)) {
      if (fileStatus === "applied" || fileStatus === "partial") {
        try {
          const govRes = await run(`
            gov=""
            for p in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do
              g=$(cat "$p" 2>/dev/null)
              [ -n "$g" ] && { gov="$g"; break; }
            done
            printf '%s' "$gov"
          `);
          const gov = (govRes.stdout || "").trim().toLowerCase();
          let expectedFromGov = null;
          if (gov === "performance") expectedFromGov = "performance";
          else if (gov === "powersave") expectedFromGov = "battery";
          else if (gov === "schedutil") expectedFromGov = "balanced";

          if (expectedFromGov && expectedFromGov !== fileMode) {
            return expectedFromGov;
          }
        } catch (e) { }
        return fileMode;
      }
    }
  }

  const fileRes = await run(`cat ${MODDIR}/.current_mode 2>/dev/null`);
  const fileMode = (fileRes.stdout || "").trim();
  if (fileMode && ["performance", "balanced", "battery"].includes(fileMode)) {
    try {
      const govRes = await run(`
        gov=""
        for p in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do
          g=$(cat "$p" 2>/dev/null)
          [ -n "$g" ] && { gov="$g"; break; }
        done
        printf '%s' "$gov"
      `);
      const gov = (govRes.stdout || "").trim().toLowerCase();
      let expectedFromGov = null;
      if (gov === "performance") expectedFromGov = "performance";
      else if (gov === "powersave") expectedFromGov = "battery";
      else if (gov === "schedutil") expectedFromGov = "balanced";
      if (expectedFromGov && expectedFromGov !== fileMode) {
        return expectedFromGov;
      }
    } catch (e) {}
    return fileMode;
  }

  try {
    const govRes = await run(`
      gov=""
      for p in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do
        g=$(cat "$p" 2>/dev/null)
        [ -n "$g" ] && { gov="$g"; break; }
      done
      printf '%s' "$gov"
    `);
    const gov = (govRes.stdout || "").trim().toLowerCase();
    if (gov === "performance") return "performance";
    if (gov === "powersave") return "battery";
    if (gov === "schedutil") return "balanced";
  } catch (e) {}

  return "";
}

async function loadBeranda() {
  if (DEMO_MODE) {
    applyDemoData();
    applyHeroState(DEMO_STATE.currentMode, DEMO_STATE.autoMode, DEMO_STATE.autoMode);
    refreshAutoStatus();
    return;
  }

  const detectedMode = await detectActiveProfile();

  if (detectedMode) {
    const fileRes = await run(`cat ${MODDIR}/.current_mode 2>/dev/null`);
    const fileMode = (fileRes.stdout || "").trim();
    if (fileMode !== detectedMode) {
      await run(`{ echo '${detectedMode}' > ${MODDIR}/.current_mode; } 2>/dev/null`);
    }
  }

  const [kernel, chipset, sdk, auto, autoapplied] = await Promise.all([
    run("uname -r"),
    run(`{ c=$(grep Hardware /proc/cpuinfo | head -1 | cut -d: -f2 | sed 's/^ *//'); [ -z "$c" ] && c=$(getprop ro.hardware); printf '%s' "$c"; }`),
    run("getprop ro.build.version.sdk"),
    run(`cat ${MODDIR}/.auto_mode 2>/dev/null`),
    run(`cat ${MODDIR}/.auto_applied 2>/dev/null`),
  ]);

  const modeMap = { battery: "Hemat Baterai", balanced: "Seimbang", performance: "Performa" };
  const currentMode = detectedMode;
  const autoModeOn = auto.stdout.trim() === "1";
  const autoApplied = autoModeOn && autoapplied.stdout.trim() === "1";

  const profileStateRes = await run(`cat ${MODDIR}/.profile_state 2>/dev/null`);
  const profileStateRaw = (profileStateRes.stdout || "").trim();
  let profileStatusText = "";
  if (profileStateRaw) {
    const psLines = profileStateRaw.split("\n");
    const psMap = {};
    psLines.forEach(line => {
      const [k, ...v] = line.split("=");
      if (k) psMap[k.trim()] = v.join("=").trim();
    });
    if (psMap.status === "partial") profileStatusText = " (partial)";
    if (psMap.applied) profileStatusText += " \u2022 " + psMap.applied + " applied";
    if (psMap.errors && psMap.errors !== "0") profileStatusText += " \u2022 " + psMap.errors + " errors";
  }

  document.getElementById("info-version").textContent = "HSIN v1-Alpha-fix1";
  document.getElementById("info-kernel").textContent = kernel.stdout.trim() || "\u2013";
  document.getElementById("info-chipset").textContent = (chipset.stdout.trim() || "\u2013");
  document.getElementById("info-sdk").textContent = sdk.stdout.trim() || "\u2013";
  document.getElementById("info-profile").textContent = currentMode ? (modeMap[currentMode] || currentMode) + profileStatusText : t("info.notset");

  applyHeroState(currentMode, autoModeOn, autoApplied);
  refreshAutoStatus();
}

async function loadMode() {
  if (DEMO_MODE) {
    highlightActiveProfile(DEMO_STATE.currentMode);
    document.getElementById("auto-mode-toggle").checked = DEMO_STATE.autoMode;
    return;
  }

  const detectedMode = await detectActiveProfile();
  highlightActiveProfile(detectedMode);

  const res = await run(`cat ${MODDIR}/.auto_mode 2>/dev/null`);
  const autoOn = (res.stdout || "").trim() === "1";
  document.getElementById("auto-mode-toggle").checked = autoOn;
}

function applyHeroState(currentMode, autoModeOn, autoApplied) {
  const titleEl = document.getElementById("hero-title");
  const subEl = document.getElementById("hero-sub");
  const badgeEl = document.getElementById("hero-auto-badge");
  const avatarEl = document.getElementById("hero-avatar");
  const tsEl = document.getElementById("hero-timestamp");

  const modeMap = { battery: "Hemat Baterai", balanced: "Seimbang", performance: "Performa" };
  const modeName = currentMode ? (modeMap[currentMode] || currentMode) : "";

  if (currentMode && currentMode !== "") {
    titleEl.textContent = t("hero.active");
    titleEl.classList.add("active");
    subEl.textContent = t("hero.active.sub") + modeName;
  } else {
    titleEl.textContent = t("hero.neutral");
    titleEl.classList.remove("active");
    subEl.textContent = t("hero.neutral.sub");
  }

  if (tsEl) {
    const lastApplied = localStorage.getItem("hsin_last_applied");
    if (lastApplied && currentMode) {
      tsEl.textContent = "Diterapkan: " + lastApplied;
      tsEl.classList.remove("hidden");
    } else {
      tsEl.classList.add("hidden");
    }
  }

  if (avatarEl) avatarEl.innerHTML = modeIcon(currentMode || "");

  if (autoApplied) {
    badgeEl.classList.remove("hidden");
  } else {
    badgeEl.classList.add("hidden");
  }
}

async function refreshAutoStatus() {
  const el = document.getElementById("hero-game-status");
  if (!el) return;
  if (DEMO_MODE) {
    if (DEMO_STATE && DEMO_STATE.currentMode === "performance") {
      el.textContent = "🎮 " + prettyName("com.levelinfinite.gst") + " aktif — Mode: Performance (Auto)";
      el.classList.remove("hidden");
    } else {
      el.classList.add("hidden");
    }
    return;
  }
  try {
    const res = await run(`cat ${MODDIR}/.auto_status 2>/dev/null`);
    const raw = (res.stdout || "").trim();
    if (!raw || raw === "|balanced|0" || raw.startsWith("|")) {
      el.classList.add("hidden");
      el.textContent = "";
      return;
    }
    const parts = raw.split("|");
    const pkg = (parts[0] || "").trim();
    const mode = (parts[1] || "").trim();
    const isGame = (parts[2] || "").trim();
    if (!pkg || isGame !== "1") {
      el.classList.add("hidden");
      el.textContent = "";
      return;
    }
    const name = prettyName(pkg);
    const modeMap = { battery: "Battery", balanced: "Seimbang", performance: "Performance", baterai: "Battery", seimbang: "Seimbang", performa: "Performance" };
    const modeName = modeMap[mode] || mode;
    if (currentLang === "en") {
      el.textContent = "🎮 " + name + " active — Mode: " + modeName + " (Auto)";
    } else {
      el.textContent = "🎮 " + name + " aktif — Mode: " + modeName + " (Auto)";
    }
    el.classList.remove("hidden");
  } catch(e) {
    el.classList.add("hidden");
  }
}
function startAutoStatus() {
  if (autoStatusTimer) return;
  refreshAutoStatus();
  autoStatusTimer = setInterval(refreshAutoStatus, 3000);
}
function stopAutoStatus() {
  if (autoStatusTimer) { clearInterval(autoStatusTimer); autoStatusTimer = null; }
}

let _currentJobId = null;
let _profilePollTimer = null;
let _applyingMode = null;

function highlightActiveProfile(mode) {
  document.querySelectorAll("#mode-buttons .profile-btn").forEach(b => {
    b.classList.toggle("active", b.dataset.mode === mode);
  });
}

function _genJobId() {
  return "j" + Date.now() + "_" + Math.random().toString(36).slice(2, 8);
}

function _setProfileStatus(html) {
  const el = document.getElementById("profile-status");
  if (el) el.innerHTML = html;
}

function _clearProfilePoll() {
  if (_profilePollTimer) { clearInterval(_profilePollTimer); _profilePollTimer = null; }
}

async function _pollProfileStatus(mode, btnLabel, attempt) {
  attempt = attempt || 0;
  if (attempt > 180) { _clearProfilePoll(); return; }

  const res = await run(`cat ${MODDIR}/.profile_status 2>/dev/null`);
  const raw = (res.stdout || "").trim();
  if (!raw) { _setProfileStatus(""); return; }

  const parts = raw.split("|");
  const jobId = parts[0] || "";
  const profile = parts[1] || "";
  const phase = parts[2] || "";
  const ok = parseInt(parts[3], 10) || 0;
  const partial = parseInt(parts[4], 10) || 0;
  const skip = parseInt(parts[5], 10) || 0;
  const fail = parseInt(parts[6], 10) || 0;
  const elapsed = parts[7] || "0";
  const warn = parseInt(parts[8], 10) || 0;
  const total = parseInt(parts[9], 10) || 0;
  const done = parseInt(parts[10], 10) || 0;
  const applyTime = parts[13] || elapsed;
  const unsupported = parseInt(parts[14], 10) || 0;
  const criticalErr = parseInt(parts[15], 10) || 0;
  const optionalErr = parseInt(parts[16], 10) || 0;

  if (_currentJobId && jobId !== _currentJobId) return;

  const _featureIcons = { applied: "\u2713", warning: "\u26A0", skipped: "\u2014", error: "\u2717" };
  const _featureClasses = { applied: "log-ok", warning: "log-warn", skipped: "log-skip", error: "log-err" };

  async function _getFeatureStatus() {
    const featRes = await run(`cat ${MODDIR}/.feature_status 2>/dev/null`);
    return (featRes.stdout || "").trim().split("\n").filter(Boolean);
  }

  function _buildProgressBar(pct, featureHtml) {
    const clampedPct = Math.max(0, Math.min(100, pct));
    return `<div class="ps-progress-bar-wrap">
      <div class="ps-progress-bar"><div class="ps-progress-bar-fill" style="width:${clampedPct}%"></div></div>
      <div class="ps-progress-pct">${clampedPct}%</div>
    </div>` + (featureHtml ? `<div class="ps-progress-wrap">${featureHtml}</div>` : "");
  }

  function _buildFeatureProgress(featLines, showCheckmarks) {
    if (!featLines.length) return "";
    const rows = featLines.map(line => {
      const fp = line.split("|");
      const name = fp[0] || "";
      const status = fp[1] || "applied";
      const duration = fp[7] || "";
      const icon = showCheckmarks ? (_featureIcons[status] || "?") : "\u25CB";
      const cls = showCheckmarks ? (_featureClasses[status] || "") : "";
      const durStr = duration ? ` <span class="ps-dur">${duration}s</span>` : "";
      return `<span class="ps-feature"><span class="${cls}">${icon}</span> ${name}${durStr}</span>`;
    }).join("");
    return rows;
  }

  switch (phase) {
    case "applying": {
      const featLines = await _getFeatureStatus();
      const featureHtml = _buildFeatureProgress(featLines, true);
      const pct = total > 0 ? Math.round((done / total) * 100) : 0;
      _setProfileStatus(
        `<span class="ps-dot ps-applying"></span> ${btnLabel} \u2014 ${t("profile.applying")}` +
        _buildProgressBar(pct, featureHtml)
      );
      break;
    }
    case "applied":
      _clearProfilePoll();
      _setProfileStatus(
        `<span class="ps-dot ps-applied"></span> ${btnLabel} \u2713 ${t("profile.applied")}` +
        `<div class="ps-progress-bar-wrap"><div class="ps-progress-bar"><div class="ps-progress-bar-fill ps-bar-done" style="width:100%"></div></div><div class="ps-progress-pct">100%</div></div>` +
        ` <span class="ps-detail">(${ok} ${t("log.applied")}, ${skip} ${t("log.skipped")}` +
        (unsupported > 0 ? `, ${unsupported} unsupported` : "") +
        `)</span>` +
        `<span class="ps-timing">${applyTime}s</span>`
      );
      _onProfileDone(mode, btnLabel);
      break;
    case "partial":
      _clearProfilePoll();
      _setProfileStatus(
        `<span class="ps-dot ps-partial"></span> ${btnLabel} \u26A0 ${t("profile.partial")}` +
        `<div class="ps-progress-bar-wrap"><div class="ps-progress-bar"><div class="ps-progress-bar-fill ps-bar-partial" style="width:100%"></div></div><div class="ps-progress-pct">100%</div></div>` +
        ` <span class="ps-detail">(${ok} ${t("log.applied")}, ${skip} ${t("log.skipped")}` +
        (unsupported > 0 ? `, ${unsupported} unsupported` : "") +
        `, ${optionalErr} optional errors` +
        (criticalErr > 0 ? `, ${criticalErr} critical` : "") +
        `)</span>` +
        `<span class="ps-timing">${applyTime}s</span>`
      );
      _onProfileDone(mode, btnLabel);
      break;
    case "failed": case "timeout":
      _clearProfilePoll();
      _setProfileStatus(
        `<span class="ps-dot ps-failed"></span> ${btnLabel} \u2715 ${phase === "timeout" ? t("profile.timeout") : t("profile.failed")}` +
        `<span class="ps-detail">(${criticalErr > 0 ? criticalErr + " critical" : fail + " " + t("log.errors")})</span>`
      );
      toast(t("toast.failed"));
      break;
    case "cancelled":
      _clearProfilePoll();
      break;
    default:
      break;
  }
}

function _onProfileDone(mode, btnLabel) {
  toast(t("toast.applied"));
  const autoOn = document.getElementById("auto-mode-toggle").checked;
  applyHeroState(mode, autoOn, autoOn);
  document.getElementById("info-profile").textContent = btnLabel;
  _applyingMode = null;
  if (mode) {
    run(`{ echo '${mode}' > ${MODDIR}/.current_mode; } 2>/dev/null`);
    const now = new Date();
    const ts = now.getFullYear() + "-" +
      String(now.getMonth() + 1).padStart(2, "0") + "-" +
      String(now.getDate()).padStart(2, "0") + " " +
      String(now.getHours()).padStart(2, "0") + ":" +
      String(now.getMinutes()).padStart(2, "0") + ":" +
      String(now.getSeconds()).padStart(2, "0");
    try { localStorage.setItem("hsin_last_applied", ts); } catch (e) {}
  }
}

let _launchLock = false;

async function _launchProfile(mode, btnLabel) {
  if (_launchLock) return; // ignore re-entrant calls (double-tap / rapid mode switch mid-launch)
  _launchLock = true;

  try {
    if (_currentJobId) {
      await run(`{ echo "${_currentJobId}|cancelled" > ${MODDIR}/.profile_status; } 2>/dev/null`);
      _clearProfilePoll();

      // Make sure the previous job's process is actually dead before we touch
      // shared state files. Without this wait, the old job can still be mid-write
      // when we rm/truncate below, corrupting .feature_status with duplicate entries
      // and causing sysfs write contention (slow I/O apply).
      await run(
        `_pf="${MODDIR}/.job_pid"; ` +
        `if [ -f "$_pf" ]; then ` +
        `  _prev_pid="$(cat "$_pf" 2>/dev/null | cut -d'|' -f2)"; ` +
        `  if [ -n "$_prev_pid" ]; then ` +
        `    kill -TERM "$_prev_pid" 2>/dev/null; ` +
        `    _w=0; ` +
        `    while kill -0 "$_prev_pid" 2>/dev/null && [ "$_w" -lt 20 ]; do sleep 0.1; _w=$((_w+1)); done; ` +
        `    kill -0 "$_prev_pid" 2>/dev/null && kill -KILL "$_prev_pid" 2>/dev/null; ` +
        `  fi; ` +
        `fi`
      );
    }

    const jobId = _genJobId();
    _currentJobId = jobId;
    _applyingMode = mode;

    await run(`rm -f ${MODDIR}/.progress ${MODDIR}/.progress_log ${MODDIR}/.apply_dedup ${MODDIR}/.feature_status ${MODDIR}/.profile_state ${MODDIR}/.job_pid 2>/dev/null`);

    await run(`{ echo "${jobId}|${mode}|applying|0|0|0|0|0|0|7|0|0|none|0||0|0|0" > ${MODDIR}/.profile_status; } 2>/dev/null`);

    _setProfileStatus(`<span class="ps-dot ps-applying"></span> ${btnLabel} \u2014 ${t("profile.applying")}`);

    run(`nohup sh ${MODDIR}/apply-profile.sh ${mode} ${jobId} > /dev/null 2>&1 &`);

    _clearProfilePoll();
    let attempt = 0;
    _profilePollTimer = setInterval(() => {
      attempt++;
      _pollProfileStatus(mode, btnLabel, attempt);
    }, 2000);
    setTimeout(() => _pollProfileStatus(mode, btnLabel, 0), 1000);
  } finally {
    _launchLock = false;
  }
}

document.querySelectorAll("#mode-buttons .profile-btn").forEach(btn => {
  btn.addEventListener("click", async () => {
    const mode = btn.dataset.mode;
    highlightActiveProfile(mode);

    const now = new Date();
    const ts = now.getFullYear() + "-" +
      String(now.getMonth() + 1).padStart(2, "0") + "-" +
      String(now.getDate()).padStart(2, "0") + " " +
      String(now.getHours()).padStart(2, "0") + ":" +
      String(now.getMinutes()).padStart(2, "0") + ":" +
      String(now.getSeconds()).padStart(2, "0");
    try { localStorage.setItem("hsin_last_applied", ts); } catch (e) {}

    if (DEMO_MODE) {
      DEMO_STATE.currentMode = mode;
      applyHeroState(mode, DEMO_STATE.autoMode, DEMO_STATE.autoMode);
      document.getElementById("info-profile").textContent = btn.textContent.trim();
      toast(t("toast.applied"));
      return;
    }

    const btnLabel = btn.textContent.trim();
    await _launchProfile(mode, btnLabel);
  });
});

const autoToggle = document.getElementById("auto-mode-toggle");

async function setAutoMode(val) {
  const on = val ? "1" : "0";
  if (DEMO_MODE) {
    DEMO_STATE.autoMode = val;
    toast(t("toast.auto." + (val ? "on" : "off")));
    applyHeroState(DEMO_STATE.currentMode, val, val);
    return;
  }
  await run(`{ echo ${on} > ${MODDIR}/.auto_mode; } 2>/dev/null`);
  toast(t("toast.auto." + (val ? "on" : "off")));
  const cur = await getMode();
  applyHeroState(cur, val, val);
}

async function getMode() {
  if (DEMO_MODE) return DEMO_STATE.currentMode;
  return await detectActiveProfile();
}

autoToggle.addEventListener("change", async () => {
  const on = autoToggle.checked;
  await setAutoMode(on);
});

let monitorTimer = null;
let autoStatusTimer = null;

function startMonitor() {
  if (monitorTimer) return;
  refreshMonitor();
  monitorTimer = setInterval(refreshMonitor, 3000);
}
function stopMonitor() {
  if (monitorTimer) { clearInterval(monitorTimer); monitorTimer = null; }
  _cpuRefs = null; _gpuRefs = null; _thermalRefs = null;
}

async function refreshMonitor() {
  if (DEMO_MODE) {
    renderDemoMonitor();
    return;
  }
  const [cpuRes, gpuRes, thermRes] = await Promise.all([
    run(buildCpuCmd()),
    run(buildGpuCmd()),
    run(buildThermalCmd()),
  ]);
  renderCpu(cpuRes.stdout);
  renderGpu(gpuRes.stdout);
  renderThermal(thermRes.stdout);
}

function buildCpuCmd() {
  return `
    for cpu in /sys/devices/system/cpu/cpu[0-9]*; do
      f=$(cat "$cpu/cpufreq/scaling_cur_freq" 2>/dev/null)
      g=$(cat "$cpu/cpufreq/scaling_governor" 2>/dev/null)
      [ -n "$f" ] && echo "$(basename $cpu):$f:$g"
    done
  `;
}
function buildGpuCmd() {
  return `
    found=0
    for d in /sys/class/devfreq/*.gpu /sys/class/kgsl/kgsl-3d0/devfreq /sys/class/devfreq/*gpu*; do
      [ -d "$d" ] || continue
      f=$(cat "$d/cur_freq" 2>/dev/null || cat "$d/min_freq" 2>/dev/null)
      g=$(cat "$d/governor" 2>/dev/null || echo "-")
      echo "$(basename $d):$f:$g"
      found=1
    done
    [ "$found" = "0" ] && echo "none"
  `;
}
function buildThermalCmd() {
  return `
    for z in /sys/class/thermal/thermal_zone*; do
      t=$(cat "$z/temp" 2>/dev/null)
      ty=$(cat "$z/type" 2>/dev/null)
      [ -n "$t" ] && echo "$ty:$t"
    done
  `;
}

let _cpuRefs = null;
function renderCpu(stdout) {
  const el = document.getElementById("cpu-monitor");
  const lines = stdout.trim().split("\n").filter(Boolean);
  if (!lines.length) { el.innerHTML = '<div class="monitor-item">No data</div>'; _cpuRefs = null; return; }

  const cores = [];
  lines.forEach(line => {
    const [name, freq, gov] = line.split(":");
    const idx = parseInt(name.replace("cpu", ""), 10);
    cores.push({ idx, freq: parseInt(freq, 10) || 0, gov: gov || "-" });
  });
  cores.sort((a, b) => a.idx - b.idx);

  let maxFreq = 0;
  cores.forEach(c => { if (c.freq > maxFreq) maxFreq = c.freq; });

  const structureChanged = !_cpuRefs || _cpuRefs.length !== cores.length ||
    cores.some((c, i) => !_cpuRefs[i] || c.idx !== _cpuRefs[i].idx);

  if (structureChanged) {
    el.innerHTML = cores.map(c => {
      const fMHz = (c.freq / 1000).toFixed(0);
      const pct = maxFreq ? (c.freq / maxFreq * 100) : 0;
      return `
        <div class="monitor-item">
          <div class="monitor-item-head">
            <span class="monitor-item-name">Core ${c.idx}</span>
            <span class="monitor-item-freq">${fMHz} MHz</span>
          </div>
          <div class="monitor-item-gov">Governor: ${c.gov}</div>
          <div class="monitor-bar"><div class="monitor-bar-fill" style="width:${pct}%"></div></div>
        </div>`;
    }).join("");
    _cpuRefs = Array.from(el.children).map((item, i) => ({
      idx: cores[i].idx,
      freqEl: item.querySelector(".monitor-item-freq"),
      govEl: item.querySelector(".monitor-item-gov"),
      barEl: item.querySelector(".monitor-bar-fill")
    }));
  }

  _cpuRefs.forEach((ref, i) => {
    const c = cores[i];
    if (!c) return;
    ref.freqEl.textContent = (c.freq / 1000).toFixed(0) + " MHz";
    ref.govEl.textContent = "Governor: " + c.gov;
    ref.barEl.style.width = (maxFreq ? (c.freq / maxFreq * 100) : 0) + "%";
  });
}

function toMHz(raw) {
  const v = parseInt(raw, 10) || 0;
  if (v > 1000000) return Math.round(v / 1000000);
  if (v > 1000) return Math.round(v / 1000);
  return v;
}

let _gpuRefs = null;
function renderGpu(stdout) {
  const el = document.getElementById("gpu-monitor");
  const lines = stdout.trim().split("\n").filter(Boolean);
  if (!lines.length || lines[0] === "none") { el.innerHTML = '<div class="monitor-item">No GPU data</div>'; _gpuRefs = null; return; }

  const seen = new Set();
  const entries = [];
  lines.forEach(line => {
    const [_name, freq, gov] = line.split(":");
    const mhz = toMHz(freq);
    const key = mhz + "|" + (gov || "-");
    if (!seen.has(key)) {
      seen.add(key);
      entries.push({ mhz, gov: gov || "-" });
    }
  });

  const structureChanged = !_gpuRefs || _gpuRefs.length !== entries.length;

  if (structureChanged) {
    el.innerHTML = entries.map(e => `
      <div class="monitor-item">
        <div class="monitor-item-head">
          <span class="monitor-item-name">GPU</span>
          <span class="monitor-item-freq">${e.mhz} MHz</span>
        </div>
        <div class="monitor-item-gov">Governor: ${e.gov}</div>
      </div>`).join("");
    _gpuRefs = Array.from(el.children).map((item) => ({
      freqEl: item.querySelector(".monitor-item-freq"),
      govEl: item.querySelector(".monitor-item-gov")
    }));
  }

  _gpuRefs.forEach((ref, i) => {
    const e = entries[i];
    if (!e) return;
    ref.freqEl.textContent = e.mhz + " MHz";
    ref.govEl.textContent = "Governor: " + e.gov;
  });
}

let _thermalRefs = null;
function renderThermal(stdout) {
  const el = document.getElementById("thermal-monitor");
  const lines = stdout.trim().split("\n").filter(Boolean);
  if (!lines.length) { el.innerHTML = '<div class="monitor-item">No data</div>'; _thermalRefs = null; return; }

  const zones = {};
  lines.forEach(line => {
    const [type, temp] = line.split(":");
    const t = parseInt(temp, 10);
    if (isNaN(t)) return;
    const celsius = t > 1000 ? (t / 1000).toFixed(1) : t.toFixed(0);
    const key = (type || "").toLowerCase().trim();
    if (!zones[key]) zones[key] = celsius + "°C";
  });

  const items = [];
  if (zones.battery) items.push({ label: "Suhu Baterai", value: zones.battery });

  const cpuPriority = ["cpu", "cputop0", "cputop1", "soc-thmzone", "soc"];
  let cpuTemp = null;
  for (const key of cpuPriority) {
    if (zones[key]) { cpuTemp = zones[key]; break; }
  }
  if (!cpuTemp) {
    for (const key of Object.keys(zones)) {
      if (key.includes("cpu")) { cpuTemp = zones[key]; break; }
    }
  }
  if (cpuTemp) items.push({ label: "Suhu CPU", value: cpuTemp });

  if (!items.length) { el.innerHTML = '<div class="monitor-item">No thermal data</div>'; _thermalRefs = null; return; }

  const structureChanged = !_thermalRefs || _thermalRefs.length !== items.length;

  if (structureChanged) {
    el.innerHTML = items.map(it => `
      <div class="monitor-item">
        <div class="monitor-item-head">
          <span class="monitor-item-name">${it.label}</span>
          <span class="monitor-item-freq">${it.value}</span>
        </div>
      </div>`).join("");
    _thermalRefs = Array.from(el.children).map((item) => ({
      freqEl: item.querySelector(".monitor-item-freq")
    }));
  }

  _thermalRefs.forEach((ref, i) => {
    ref.freqEl.textContent = items[i].value;
  });
}

let _allPackages = [];
let _gameSetCache = new Set();
let _appProfiles = {};

function prettyName(pkg) {
  const parts = pkg.split(".");
  let last = parts[parts.length - 1];
  if (["gp", "google", "android", "mobile", "global", "en", "app"].includes(last) && parts.length > 1) {
    last = parts[parts.length - 2];
  }
  return last
    .replace(/[_\-]+/g, " ")
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .replace(/\b\w/g, c => c.toUpperCase());
}

async function loadGameList() {
  const listEl = document.getElementById("game-list");
  listEl.innerHTML = '<div class="empty-state skeleton skeleton-card"></div>';

  const [pkgsRes, gameFileRes, appProfileRes] = await Promise.all([
    DEMO_MODE
      ? Promise.resolve({ stdout: DEMO_GAMES.map(g => "package:" + g.pkg).join("\n") })
      : run("pm list packages -3 | sed 's/^package://' | sort"),
    DEMO_MODE
      ? Promise.resolve({ stdout: DEMO_GAMES.filter(g => g.active).map(g => g.pkg).join("\n") })
      : run(`cat ${MODDIR}/Misc/Game.txt 2>/dev/null`),
    DEMO_MODE
      ? Promise.resolve({ stdout: "" })
      : run(`cat ${MODDIR}/Misc/AppProfiles.txt 2>/dev/null`),
  ]);

  const pkgs = (pkgsRes.stdout || "").split("\n").map(s => s.trim()).filter(Boolean);
  _gameSetCache = new Set(gameFileRes.stdout.split("\n").map(s => s.trim()).filter(Boolean));

  _appProfiles = {};
  appProfileRes.stdout.split("\n").map(s => s.trim()).filter(Boolean).forEach(line => {
    const [pkg, mode] = line.split("=");
    if (pkg) _appProfiles[pkg] = mode;
  });

  _allPackages = pkgs.map(pkg => ({ pkg, active: _gameSetCache.has(pkg) }));
  _allPackages.sort((a, b) => (b.active - a.active) || a.pkg.localeCompare(b.pkg));

  renderGameList(_allPackages);
  renderThirdParty();
}

function renderGameList(items) {
  const listEl = document.getElementById("game-list");
  if (!listEl) return;
  listEl.innerHTML = "";

  const activeItems = items.filter(i => i.active);
  if (!activeItems.length) {
    const q = (document.getElementById("search-input")?.value || "").trim();
    if (q) {
      listEl.innerHTML = '<div class="empty-state" style="padding:28px 12px;color:#8e8e93;">Tidak ada hasil untuk "'+ q.replace(/</g,"&lt;") +'"</div>';
    } else {
      listEl.innerHTML = '<div class="empty-state" style="padding:28px 12px;color:#8e8e93;line-height:1.5;">Belum ada game<br><span style="font-size:12px;color:#6e6e73;">Tambahkan dari daftar APLIKASI PIHAK KETIGA di bawah</span></div>';
    }
    return;
  }

  activeItems.forEach(item => {
    const row = document.createElement("div");
    row.className = "app-card active";
    row.innerHTML = `
      <div class="app-icon-wrap active">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="11" rx="5"/><path d="M6 12h4M8 10v4"/><circle cx="15.5" cy="10.5" r="1"/><circle cx="18" cy="13" r="1"/></svg>
      </div>
      <div class="app-card-body">
        <div class="app-card-title">${prettyName(item.pkg)}</div>
        <div class="app-card-pkg">${item.pkg}</div>
      </div>
      <button class="app-action-btn hapus">Hapus</button>
    `;
    const btn = row.querySelector(".app-action-btn.hapus");
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      toggleGame(item);
    });
    row.addEventListener("click", () => toggleGame(item));
    listEl.appendChild(row);
  });
}

async function toggleGame(item) {
  let target = _allPackages.find(p => p.pkg === item.pkg);
  if (!target) {
    target = { pkg: item.pkg, active: false };
    _allPackages.push(target);
    _allPackages.sort((a,b)=> (b.active - a.active) || a.pkg.localeCompare(b.pkg));
  }
  target.active = !target.active;
  if (target.active) _gameSetCache.add(target.pkg);
  else _gameSetCache.delete(target.pkg);

  if (DEMO_MODE) {
    toast(prettyName(target.pkg) + (target.active ? " " + t("toast.added") : " " + t("toast.removed")) + " (demo)");
    const q = (document.getElementById("search-input")?.value || "").trim().toLowerCase();
    if (q) {
      const filtered = _allPackages.filter(i => i.pkg.toLowerCase().includes(q) || prettyName(i.pkg).toLowerCase().includes(q));
      renderGameList(filtered);
      let filteredInactive = filtered.filter(i => !i.active);
      const extra = DEMO_THIRDPARTY.filter(p => !_gameSetCache.has(p) && (p.toLowerCase().includes(q) || prettyName(p).toLowerCase().includes(q))).map(pkg=>({pkg,active:false})).filter(e=>!filteredInactive.find(f=>f.pkg===e.pkg));
      filteredInactive = [...filteredInactive, ...extra];
      renderThirdParty(filteredInactive);
    } else {
      renderGameList(_allPackages);
      renderThirdParty();
    }
    return;
  }
  const content = Array.from(_gameSetCache).sort().join("\n");
  await run(`mkdir -p ${MODDIR}/Misc && cat <<'EOF' > ${MODDIR}/Misc/Game.txt\n${content}\nEOF`);
  toast(prettyName(target.pkg) + (target.active ? " " + t("toast.added") : " " + t("toast.removed")) + " Game Saya");
  const q2 = (document.getElementById("search-input")?.value || "").trim().toLowerCase();
  if (q2) {
    const filtered = _allPackages.filter(i => i.pkg.toLowerCase().includes(q2) || prettyName(i.pkg).toLowerCase().includes(q2));
    renderGameList(filtered);
    renderThirdParty(filtered.filter(i => !i.active));
  } else {
    renderGameList(_allPackages);
    renderThirdParty();
  }
}

document.getElementById("search-input")?.addEventListener("input", (e) => {
  const q = e.target.value.trim().toLowerCase();
  if (!q) {
    renderGameList(_allPackages);
    renderThirdParty();
    return;
  }
  const filtered = _allPackages.filter(i =>
    i.pkg.toLowerCase().includes(q) || prettyName(i.pkg).toLowerCase().includes(q)
  );
  renderGameList(filtered);
  let filteredInactive = filtered.filter(i => !i.active);
  if (DEMO_MODE) {
    const extra = DEMO_THIRDPARTY.filter(p => !_gameSetCache.has(p) && (p.toLowerCase().includes(q) || prettyName(p).toLowerCase().includes(q))).map(pkg=>({pkg,active:false})).filter(ex=>!filteredInactive.find(f=>f.pkg===ex.pkg));
    filteredInactive = [...filteredInactive, ...extra];
  }
  renderThirdParty(filteredInactive);
});

async function renderThirdParty(filteredInactive) {
  const listEl = document.getElementById("thirdparty-list");
  if (!listEl) return;

  let inactive;
  if (Array.isArray(filteredInactive)) {
    inactive = filteredInactive;
  } else if (DEMO_MODE) {
    const fromPkgs = _allPackages.filter(i => !i.active);
    const extra = DEMO_THIRDPARTY.filter(p => !_gameSetCache.has(p) && !fromPkgs.find(i=>i.pkg===p)).map(pkg => ({ pkg, active: false }));
    inactive = [...fromPkgs, ...extra];
  } else if (_allPackages.length) {
    inactive = _allPackages.filter(i => !i.active);
  } else {
    let pkgs;
    const res = await run("pm list packages -3 | sed 's/^package://' | sort");
    pkgs = (res.stdout || "").split("\n").map(s => s.trim()).filter(Boolean);
    inactive = pkgs.filter(p => !_gameSetCache.has(p)).map(pkg => ({ pkg, active: false }));
  }

  if (!inactive.length) {
    const q = (document.getElementById("search-input")?.value || "").trim();
    if (q) {
      listEl.innerHTML = '<div class="empty-state" style="padding:28px 12px;color:#8e8e93;">Tidak ada hasil untuk "'+ q.replace(/</g,"&lt;") +'"</div>';
    } else {
      listEl.innerHTML = '<div class="empty-state" style="padding:28px 12px;color:#8e8e93;">Tidak ada aplikasi pihak ketiga</div>';
    }
    return;
  }

  inactive.sort((a,b)=> a.pkg.localeCompare(b.pkg));
  const toShow = inactive.slice(0, DEMO_MODE ? 5 : 50);

  listEl.innerHTML = "";
  toShow.forEach(item => {
    const pkg = typeof item === "string" ? item : item.pkg;
    const row = document.createElement("div");
    row.className = "app-card inactive";
    row.innerHTML = `
      <div class="app-icon-wrap inactive">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>
      </div>
      <div class="app-card-body">
        <div class="app-card-title">${prettyName(pkg)}</div>
        <div class="app-card-pkg">${pkg}</div>
      </div>
      <button class="app-action-btn tambah">Tambah</button>
    `;
    const btn = row.querySelector(".app-action-btn.tambah");
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const fake = { pkg, active: false };
      toggleGame(fake);
    });
    listEl.appendChild(row);
  });
}

async function updateAppProfile(pkg, mode) {
  _appProfiles[pkg] = mode;
  if (DEMO_MODE) {
    toast(t("toast.added") + ": " + prettyName(pkg));
    return;
  }
  const lines = Object.entries(_appProfiles).map(([p, m]) => `${p}=${m}`).join("\n");
  await run(`cat <<'EOF' > ${MODDIR}/Misc/AppProfiles.txt\n${lines}\nEOF`);
  toast(t("toast.added") + ": " + prettyName(pkg));
}

async function removeAppProfile(pkg) {
  delete _appProfiles[pkg];
  if (DEMO_MODE) {
    toast(t("toast.removed") + ": " + prettyName(pkg));
    renderThirdParty();
    return;
  }
  const lines = Object.entries(_appProfiles).map(([p, m]) => `${p}=${m}`).join("\n");
  await run(`cat <<'EOF' > ${MODDIR}/Misc/AppProfiles.txt\n${lines}\nEOF`);
  toast(t("toast.removed") + ": " + prettyName(pkg));
  renderThirdParty();
}

document.getElementById("btn-add-thirdparty")?.addEventListener("click", () => {
  document.getElementById("modal-thirdparty").classList.remove("hidden");
});
document.getElementById("modal-cancel")?.addEventListener("click", () => {
  document.getElementById("modal-thirdparty").classList.add("hidden");
});
document.getElementById("modal-backdrop")?.addEventListener("click", () => {
  document.getElementById("modal-thirdparty").classList.add("hidden");
});
document.getElementById("modal-confirm")?.addEventListener("click", async () => {
  const pkg = document.getElementById("modal-pkg-input").value.trim();
  const mode = document.getElementById("modal-mode-select").value;
  if (!pkg) { toast("Isi package name"); return; }
  await updateAppProfile(pkg, mode);
  if (!_allPackages.find(p=>p.pkg===pkg) && !_gameSetCache.has(pkg)) {
    _allPackages.push({ pkg, active: false });
    _allPackages.sort((a,b)=> (b.active - a.active) || a.pkg.localeCompare(b.pkg));
  }
  document.getElementById("modal-thirdparty").classList.add("hidden");
  document.getElementById("modal-pkg-input").value = "";
  const q = (document.getElementById("search-input")?.value||"").trim().toLowerCase();
  if (q) {
    const filtered = _allPackages.filter(i=> !i.active && (i.pkg.toLowerCase().includes(q) || prettyName(i.pkg).toLowerCase().includes(q)));
    renderThirdParty(filtered);
  } else {
    renderThirdParty();
  }
});

function applyTheme(theme) {
  currentTheme = theme;
  if (theme === "light") document.body.setAttribute("data-theme", "light");
  else document.body.removeAttribute("data-theme");
  const toggle = document.getElementById("theme-toggle");
  if (toggle) toggle.checked = (theme === "dark");
  savePref("hsin_theme", theme);
}
document.getElementById("theme-toggle")?.addEventListener("change", (e) => {
  applyTheme(e.target.checked ? "dark" : "light");
  toast(t("toast.theme"));
});

document.getElementById("language-select")?.addEventListener("change", (e) => {
  currentLang = e.target.value;
  savePref("hsin_lang", currentLang);
  applyI18n();
  toast(t("toast.lang"));
  if (!document.getElementById("page-mode").classList.contains("hidden")) loadMode();
  if (!document.getElementById("page-utama").classList.contains("hidden")) loadBeranda();
});

document.getElementById("btn-about")?.addEventListener("click", () => {
  openSubPage("about");
});
// Log button removed from Settings UI - log is accessible via bottom nav or dedicated page

document.getElementById("btn-update-check")?.addEventListener("click", async () => {
  toast(t("toast.update.nodata"));
  const url = "https://github.com/CLEVERdumb/HSIN/releases";
  if (DEMO_MODE || typeof ksu === "undefined") {
    try { window.open(url, "_blank"); } catch (e) {}
  } else {
    try {
      if (navigator.clipboard) { await navigator.clipboard.writeText(url); toast(t("toast.copied")); }
      else { window.open(url, "_blank"); }
    } catch (e) { window.open(url, "_blank"); }
  }
});

async function loadLog() {
  const summaryTs = document.getElementById("log-summary-ts");
  const summaryProfile = document.getElementById("log-summary-profile");
  const featuresEl = document.getElementById("log-features");
  const statsEl = document.getElementById("log-stats");
  const contentEl = document.getElementById("log-content");
  const warnEl = document.getElementById("log-warnings");

  if (DEMO_MODE) {
    if (summaryTs) summaryTs.textContent = "[18:08:32]";
    if (summaryProfile) summaryProfile.textContent = "Profile balanced applied";
    if (featuresEl) featuresEl.innerHTML = [
      { name: "CPU", status: "applied" },
      { name: "GPU", status: "applied" },
      { name: "I/O", status: "applied" },
      { name: "Thermal", status: "applied" },
      { name: "Gaming", status: "skipped" },
    ].map(f => {
      const icon = f.status === "applied" ? "✓" : f.status === "error" ? "✗" : "—";
      const cls = f.status === "applied" ? "log-ok" : f.status === "error" ? "log-err" : "log-skip";
      return `<div class="log-feature-row"><span class="log-feature-icon ${cls}">${icon}</span> ${f.name}</div>`;
    }).join("");
    if (statsEl) statsEl.innerHTML = `<span class="log-stat-ok">172 ${t("log.applied")}</span> · <span class="log-stat-skip">31 ${t("log.skipped")}</span> · <span class="log-stat-err">0 ${t("log.errors")}</span>`;
    if (contentEl) contentEl.textContent = "Demo log — full details would appear here.";
    if (warnEl) { warnEl.classList.add("hidden"); warnEl.innerHTML = ""; }
    return;
  }

  const featRes = await run(`cat ${MODDIR}/.feature_status 2>/dev/null`);
  const featLines = (featRes.stdout || "").trim().split("\n").filter(Boolean);

  if (featuresEl) {
    if (featLines.length) {
      featuresEl.innerHTML = featLines.map(line => {
        const parts = line.split("|");
        const name = parts[0] || "";
        const status = parts[1] || "applied";
        const duration = parts[7] || "";
        const icon = status === "applied" ? "✓" : status === "error" ? "✗" : status === "warning" ? "⚠" : "—";
        const cls = status === "applied" ? "log-ok" : status === "error" ? "log-err" : status === "warning" ? "log-warn" : "log-skip";
        const durStr = duration ? ` <span class="ps-dur">${duration}s</span>` : "";
        return `<div class="log-feature-row"><span class="log-feature-icon ${cls}">${icon}</span> ${name}${durStr}</div>`;
      }).join("");
    } else {
      featuresEl.innerHTML = `<div class="log-feature-row" style="color:var(--text-dim);">No feature data yet</div>`;
    }
  }

  const uiLogRes = await run(`tail -n 10 ${MODDIR}/hsin_ui.log 2>/dev/null`);
  const uiLog = (uiLogRes.stdout || "").trim();
  const uiLines = uiLog.split("\n").filter(Boolean);
  let lastProfile = "";
  let lastTs = "";
  for (let i = uiLines.length - 1; i >= 0; i--) {
    const m = uiLines[i].match(/^\[(\d{2}:\d{2}:\d{2})\] Profile (\w+) applied/);
    if (m) { lastTs = m[1]; lastProfile = m[2]; break; }
  }
  if (summaryTs) summaryTs.textContent = lastTs ? `[${lastTs}]` : "";
  if (summaryProfile) summaryProfile.textContent = lastProfile ? `Profile ${lastProfile} applied` : "";

  const statusRes = await run(`cat ${MODDIR}/.profile_status 2>/dev/null`);
  const sp = (statusRes.stdout || "").trim().split("|");
  const ok = parseInt(sp[3], 10) || 0;
  const skip = parseInt(sp[5], 10) || 0;
  const fail = parseInt(sp[6], 10) || 0;
  const elapsed = sp[7] || "0";
  const applyTime = sp[13] || elapsed;
  const unsupported = parseInt(sp[14], 10) || 0;
  const criticalErr = parseInt(sp[15], 10) || 0;
  const optionalErr = parseInt(sp[16], 10) || 0;

  if (statsEl) {
    let statsHtml = `<span class="log-stat-ok">${ok} ${t("log.applied")}</span> · <span class="log-stat-skip">${skip} ${t("log.skipped")}</span>`;
    if (unsupported > 0) statsHtml += ` · <span class="log-stat-sup">${unsupported} unsupported</span>`;
    if (fail > 0) {
      if (criticalErr > 0) statsHtml += ` · <span class="log-stat-err">${criticalErr} critical errors</span>`;
      if (optionalErr > 0) statsHtml += ` · <span class="log-stat-warn">${optionalErr} optional errors</span>`;
    } else {
      statsHtml += ` · <span class="log-stat-err">0 errors</span>`;
    }
    statsHtml += `<span class="log-stat-time">${applyTime}s</span>`;
    statsEl.innerHTML = statsHtml;
  }

  if (contentEl) {
    const fullRes = await run(`tail -n 100 ${MODDIR}/hsin.log 2>/dev/null || echo ""`);
    contentEl.textContent = (fullRes.stdout || "").trim() || t("log.empty");
  }

  if (warnEl && contentEl) {
    const fullLines = contentEl.textContent.split("\n");
    const fails = [];
    fullLines.forEach((line, idx) => {
      if (/\[FAIL\]/.test(line)) {
        fails.push(idx + 1);
      }
    });
    if (fails.length) {
      warnEl.classList.remove("hidden");
      warnEl.innerHTML = fails.map(n => `<span class="log-badge log-badge-error">\u26a0 ${t("log.warning")} ${n}</span>`).join(" ");
    } else {
      warnEl.classList.add("hidden");
      warnEl.innerHTML = "";
    }
  }
}

document.getElementById("btn-log-details")?.addEventListener("click", () => {
  const panel = document.getElementById("log-details-panel");
  const arrow = document.getElementById("log-details-arrow");
  const label = document.querySelector("#btn-log-details [data-i18n]");
  if (!panel) return;
  panel.classList.toggle("hidden");
  const isOpen = !panel.classList.contains("hidden");
  if (arrow) arrow.textContent = isOpen ? "‹" : "›";
  if (label) label.textContent = isOpen ? t("log.hide_details") : t("log.show_details");
});

document.getElementById("btn-saweria")?.addEventListener("click", () => openExternal("https://saweria.co/cleverdumb"));
document.getElementById("btn-github")?.addEventListener("click", () => openExternal("https://github.com/CLEVERdumb/HSIN"));

function openExternal(url) {
  if (DEMO_MODE || typeof ksu === "undefined") {
    try { window.open(url, "_blank"); } catch (e) { toast(t("toast.copied")); }
    return;
  }
  try { window.open(url, "_blank"); }
  catch (e) {
    if (navigator.clipboard) { navigator.clipboard.writeText(url).then(() => toast(t("toast.copied"))); }
  }
}

async function loadDndState() {
  const toggle = document.getElementById("dnd-toggle");
  if (!toggle || DEMO_MODE) return;
  const res = await run(`cat ${MODDIR}/.game_dnd 2>/dev/null`);
  toggle.checked = (res.stdout || "").trim() === "1";
}

document.getElementById("dnd-toggle")?.addEventListener("change", async (e) => {
  const on = e.target.checked ? "1" : "0";
  if (DEMO_MODE) { toast(t("toast.dnd." + (on === "1" ? "on" : "off"))); return; }
  await run(`{ echo ${on} > ${MODDIR}/.game_dnd; } 2>/dev/null`);
  toast(t("toast.dnd." + (on === "1" ? "on" : "off")));
});

async function loadPowerSaveState() {
  const toggle = document.getElementById("powersave-toggle");
  if (!toggle || DEMO_MODE) return;
  const res = await run(`cat ${MODDIR}/.powersave_auto 2>/dev/null`);
  toggle.checked = (res.stdout || "").trim() !== "0";
}

document.getElementById("powersave-toggle")?.addEventListener("change", async (e) => {
  const on = e.target.checked ? "1" : "0";
  if (DEMO_MODE) return;
  await run(`{ echo ${on} > ${MODDIR}/.powersave_auto; } 2>/dev/null`);
});

async function refreshGameState() {
  const el = document.getElementById("game-state-badge");
  if (!el) return;
  if (DEMO_MODE) { el.classList.add("hidden"); return; }
  try {
    const [stateRes, gameRes] = await Promise.all([
      run(`cat ${MODDIR}/.game_state 2>/dev/null`),
      run(`cat ${MODDIR}/.current_game 2>/dev/null`),
    ]);
    const state = (stateRes.stdout || "").trim();
    const game = (gameRes.stdout || "").trim();
    if (state === "GAME_ACTIVE" && game) {
      el.textContent = "🎮 " + prettyName(game) + " — " + t("game.state.active");
      el.classList.remove("hidden");
    } else if (state === "POWER_SAVE") {
      el.textContent = "🔋 " + t("game.state.powersave");
      el.classList.remove("hidden");
    } else {
      el.classList.add("hidden");
    }
  } catch(e) { el.classList.add("hidden"); }
}

let _gameStateTimer = null;
function startGameStateMonitor() {
  if (_gameStateTimer) return;
  refreshGameState();
  _gameStateTimer = setInterval(refreshGameState, 5000);
}
function stopGameStateMonitor() {
  if (_gameStateTimer) { clearInterval(_gameStateTimer); _gameStateTimer = null; }
}

async function generateDiagnostic() {
  if (DEMO_MODE) { toast(t("toast.diagnostic.done") + " (demo)"); return; }
  toast(t("toast.diagnostic.generating"));
  const script = `
    LOGFILE="${MODDIR}/diagnostic_$(date +%Y%m%d_%H%M%S).txt"
    {
      echo "=== HSIN DIAGNOSTIC REPORT ==="
      echo "Timestamp: $(date)"
      echo "Hsin version: $(cat ${MODDIR}/module.prop 2>/dev/null | grep version= | cut -d= -f2)"
      echo ""
      echo "=== DEVICE ==="
      echo "Manufacturer: $(getprop ro.product.manufacturer)"
      echo "Model: $(getprop ro.product.model)"
      echo "SoC: $(getprop ro.hardware)"
      echo "Android: $(getprop ro.build.version.release) (SDK $(getprop ro.build.version.sdk))"
      echo "Kernel: $(uname -r)"
      echo "Architecture: $(uname -m)"
      echo "SELinux: $(getenforce 2>/dev/null || echo unknown)"
      echo "Root: $(id 2>/dev/null)"
      echo ""
      echo "=== GAME MODE ==="
      echo "Auto Mode: $(cat ${MODDIR}/.auto_mode 2>/dev/null || echo 0)"
      echo "Current State: $(cat ${MODDIR}/.game_state 2>/dev/null || echo IDLE)"
      echo "Current Game: $(cat ${MODDIR}/.current_game 2>/dev/null || echo none)"
      echo "Applied Profile: $(cat ${MODDIR}/.applied_mode 2>/dev/null || echo none)"
      echo ""
      echo "=== POWER SAVE ==="
      echo "low_power: $(su -c 'settings get global low_power' 2>/dev/null || echo unknown)"
      echo ""
      echo "=== DND ==="
      echo "Game DND enabled: $(cat ${MODDIR}/.game_dnd 2>/dev/null || echo 0)"
      echo "Current DND: $(su -c 'dumpsys notification' 2>/dev/null | grep mZenMode= | head -1)"
      echo ""
      echo "=== GAME CONFIG ==="
      echo "Game list: $(wc -l < ${MODDIR}/Misc/Game.txt 2>/dev/null || echo 0) games"
      echo "AppProfiles: $(wc -l < ${MODDIR}/Misc/AppProfiles.txt 2>/dev/null || echo 0) entries"
      echo ""
      echo "=== CPU ==="
      for p in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do
        echo "  $(echo $p | grep -oE 'policy[0-9]+'): $(cat $p 2>/dev/null)"
      done
      for p in /sys/devices/system/cpu/cpufreq/policy*/scaling_cur_freq; do
        echo "  $(echo $p | grep -oE 'policy[0-9]+') freq: $(cat $p 2>/dev/null) kHz"
      done
      echo ""
      echo "=== GPU ==="
      for d in /sys/class/devfreq/23100000.gpu /sys/class/devfreq/*gpu*; do
        [ -d "$d" ] || continue
        echo "  Path: $d"
        echo "  Governor: $(cat $d/governor 2>/dev/null)"
        echo "  Cur freq: $(cat $d/cur_freq 2>/dev/null || cat $d/min_freq 2>/dev/null)"
        echo "  Max freq: $(cat $d/max_freq 2>/dev/null)"
      done
      echo ""
      echo "=== THERMAL ==="
      for z in $(ls -d /sys/class/thermal/thermal_zone* 2>/dev/null | head -5); do
        echo "  $(cat $z/type 2>/dev/null): $(cat $z/temp 2>/dev/null)"
      done
      echo ""
      echo "=== DETECTION BACKEND ==="
      echo "Logcat events: $(su -c 'logcat -b events -v raw -d' 2>/dev/null | grep -c am_focused_activity 2>/dev/null || echo 0) am_focused_activity events"
      echo "Dumpsys window: $(su -c 'dumpsys window' 2>/dev/null | grep -c mCurrentFocus 2>/dev/null || echo 0) focus entries"
      echo ""
      echo "=== PROFILE STATUS ==="
      cat ${MODDIR}/.profile_status 2>/dev/null || echo "none"
      echo ""
      echo "=== RECENT LOG ==="
      tail -30 ${MODDIR}/hsin.log 2>/dev/null || echo "no log"
    } > "$LOGFILE" 2>&1
    echo "$LOGFILE"
  `;
  const res = await run(script);
  const path = (res.stdout || "").trim();
  if (path && path.startsWith("/")) {
    toast(t("toast.diagnostic.done") + ": " + path.split("/").pop());
  } else {
    toast(t("toast.diagnostic.failed"));
  }
}

// Diagnostic removed from Settings UI

const DEMO_STATE = { currentMode: "balanced", autoMode: false };
const DEMO_GAMES = [
  { pkg: "com.levelinfinite.gst", active: true },
  { pkg: "com.kurogame.gplay.p", active: true },
  { pkg: "com.kurogame.wutheringwaves.global", active: true },
  { pkg: "com.google.android.co", active: false },
  { pkg: "com.axis.net", active: false },
];
const DEMO_THIRDPARTY = [
  "com.whatsapp", "com.instagram.android", "com.spotify.music",
  "com.twitter.android", "com.netflix.mediaclient"
];

function applyDemoData() {
    document.getElementById("info-version").textContent = "HSIN v1-Alpha-fix1";
    document.getElementById("info-kernel").textContent = "5.15.x-demo";
  document.getElementById("info-chipset").textContent = "unisoc";
  document.getElementById("info-sdk").textContent = "34";
  const modeMap = { battery: "Hemat Baterai", balanced: "Seimbang", performance: "Performa" };
  const m = DEMO_STATE.currentMode;
  document.getElementById("info-profile").textContent = modeMap[m] || "Belum diatur";
}

function renderDemoMonitor() {
  const cpuEl = document.getElementById("cpu-monitor");
  const gpuEl = document.getElementById("gpu-monitor");
  const thermEl = document.getElementById("thermal-monitor");

  const demoFreqs = [1200, 1200, 1400, 1400, 1800, 1800, 2200, 2400];
  const maxF = Math.max(...demoFreqs);

  const structureChanged = !_cpuRefs || _cpuRefs.length !== demoFreqs.length;

  if (structureChanged) {
    cpuEl.innerHTML = demoFreqs.map((f, i) => `
      <div class="monitor-item"><div class="monitor-item-head"><span class="monitor-item-name">Core ${i}</span><span class="monitor-item-freq">${f} MHz</span></div><div class="monitor-item-gov">Governor: schedutil</div><div class="monitor-bar"><div class="monitor-bar-fill" style="width:${(f / maxF * 100).toFixed(0)}%"></div></div></div>`
    ).join("");
    _cpuRefs = Array.from(cpuEl.children).map((item, i) => ({
      idx: i,
      freqEl: item.querySelector(".monitor-item-freq"),
      govEl: item.querySelector(".monitor-item-gov"),
      barEl: item.querySelector(".monitor-bar-fill")
    }));
  }
  _cpuRefs.forEach((ref, i) => {
    const f = demoFreqs[i];
    ref.freqEl.textContent = f + " MHz";
    ref.govEl.textContent = "Governor: schedutil";
    ref.barEl.style.width = (f / maxF * 100).toFixed(0) + "%";
  });

  if (!_gpuRefs) {
    gpuEl.innerHTML = `
      <div class="monitor-item"><div class="monitor-item-head"><span class="monitor-item-name">GPU</span><span class="monitor-item-freq">850 MHz</span></div><div class="monitor-item-gov">Governor: drm_gpu</div></div>
    `;
    _gpuRefs = [{ freqEl: gpuEl.querySelector(".monitor-item-freq"), govEl: gpuEl.querySelector(".monitor-item-gov") }];
  }
  _gpuRefs[0].freqEl.textContent = "850 MHz";
  _gpuRefs[0].govEl.textContent = "Governor: drm_gpu";

  if (!_thermalRefs) {
    thermEl.innerHTML = `
      <div class="monitor-item"><div class="monitor-item-head"><span class="monitor-item-name">Suhu Baterai</span><span class="monitor-item-freq">35.2°C</span></div></div>
      <div class="monitor-item"><div class="monitor-item-head"><span class="monitor-item-name">Suhu CPU</span><span class="monitor-item-freq">41.0°C</span></div></div>
    `;
    _thermalRefs = Array.from(thermEl.children).map(item => ({
      freqEl: item.querySelector(".monitor-item-freq")
    }));
  }
  _thermalRefs[0].freqEl.textContent = "35.2°C";
  _thermalRefs[1].freqEl.textContent = "41.0°C";
}

function applyBackground(name) {
  if (!name || name === "default") {
    document.body.style.backgroundImage = "";
    document.body.style.backgroundSize = "";
    document.body.style.backgroundAttachment = "";
  } else {
    document.body.style.backgroundImage = `url('backgrounds/${name}')`;
    document.body.style.backgroundSize = "cover";
    document.body.style.backgroundAttachment = "fixed";
    document.body.style.backgroundPosition = "center";
    document.body.style.backgroundRepeat = "no-repeat";
  }
  document.querySelectorAll(".bg-thumb").forEach(b => {
    b.classList.toggle("active", b.dataset.bg === name);
  });
  try { localStorage.setItem("hsin_bg", name); } catch(e) {}
  if (!DEMO_MODE) {
    run(`cp "${MODDIR}/background.jpg" "${MODDIR}/webroot/backgrounds/background.jpg" 2>/dev/null; cp "${MODDIR}/bekron.jpg" "${MODDIR}/webroot/backgrounds/bekron.jpg" 2>/dev/null; echo`);
  }
}

function setupBackground() {
  document.querySelectorAll(".bg-thumb").forEach(btn => {
    btn.addEventListener("click", () => {
      const bg = btn.dataset.bg;
      applyBackground(bg);
      toast(t("toast.bg"));
    });
  });
  if (!DEMO_MODE) {
    run(`mkdir -p ${MODDIR}/webroot/backgrounds 2>/dev/null; cp "${MODDIR}/background.jpg" "${MODDIR}/webroot/backgrounds/background.jpg" 2>/dev/null; cp "${MODDIR}/bekron.jpg" "${MODDIR}/webroot/backgrounds/bekron.jpg" 2>/dev/null; ls "${MODDIR}/webroot/backgrounds" 2>/dev/null`);
  }
}

function init() {
  try {
    const savedBg = localStorage.getItem("hsin_bg") || "default";
    applyBackground(savedBg);
  } catch(e) {}
  setupBackground();
  const savedTheme = loadPref("hsin_theme") || "dark";
  applyTheme(savedTheme);
  const savedLang = loadPref("hsin_lang") || "id";
  currentLang = savedLang;
  const langSel = document.getElementById("language-select");
  if (langSel) langSel.value = currentLang;
  applyI18n();

  document.getElementById("about-name").textContent = "HSIN Gaming Module";
  document.getElementById("about-version").textContent = "v1-Alpha-fix1";
  document.getElementById("about-author").textContent = "CLEVERdumb";
  document.getElementById("about-detail-version").textContent = "v1-Alpha-fix1";

  loadBeranda();
  startAutoStatus();
  loadAutoModeInit();
  loadDndState();
  loadPowerSaveState();
  startGameStateMonitor();
}

async function loadAutoModeInit() {
  let on = false;
  if (DEMO_MODE) on = DEMO_STATE.autoMode;
  else {
    const res = await run(`cat ${MODDIR}/.auto_mode 2>/dev/null`);
    on = res.stdout.trim() === "1";
  }
  autoToggle.checked = on;
}

init();
