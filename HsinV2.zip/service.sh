#!/system/bin/sh
# HSIN Service — v2.2 Surgical Fix
# - Wait for boot complete
# - Single Source of Truth: .current_mode
# - Debounced game detection
# - Proper cleanup

MODDIR=${0%/*}
HSIN_LOG="$MODDIR/hsin.log"

# ── Wait for boot complete ──────────────────────────────────
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 1
done
sleep 3

# ── Clean old state ─────────────────────────────────────────
rm -f "$MODDIR/hsin.log" "$MODDIR/hsin_ui.log" 2>/dev/null
rm -f "$MODDIR"/.feature_status "$MODDIR"/.profile_status 2>/dev/null
rm -f "$MODDIR"/.progress "$MODDIR"/.progress_log 2>/dev/null
rm -f "$MODDIR"/.apply_dedup "$MODDIR"/.job_pid 2>/dev/null
rm -rf "$MODDIR"/.rollback 2>/dev/null

pkill -f "hsin_game_mode" 2>/dev/null
pkill -f "hsin_powersave" 2>/dev/null

echo "" > "$MODDIR/.game_state" 2>/dev/null
echo "" > "$MODDIR/.current_game" 2>/dev/null
rm -f "$MODDIR/.pre_game_mode" "$MODDIR/.pre_powersave_mode" 2>/dev/null

. "$MODDIR/lib/hsin_common.sh"
. "$MODDIR/lib/hsin_detect.sh"

hsin_detect_all

vlkn() {
    resetprop -n renderthread.vulkanthreaded.reduceopstasksplitting true
    resetprop -n ro.hwui.hardware.vulkan true
    resetprop -n ro.hwui.use_vulkan true
    resetprop -n ro.ui.pipeline skiavk
    resetprop -n ro.hwui.skia.show_vulkan_pipeline true
    resetprop -n debug.hwui.renderer skiavk
    resetprop -n vendor.debug.renderengine.backend skiavk
    resetprop -n debug.renderengine.backend skiavk
    resetprop -n debug.hwui.level high
    resetprop -n debug.overlayui.enable 1
    resetprop -n debug.performance.tuning 1
    resetprop -n hwui.render_dirty_regions false
    resetprop -n hwui.disable_vsync true
    resetprop -n persist.cpu.freq.boost 1
    resetprop -n persist.sys.disable_skia_path_ops false
    resetprop -n ro.config.hw_high_perf true
    resetprop -n debug.hwui.disable_scissor_opt true
    resetprop -n debug.vulkan.layers.enable 1
    resetprop -n persist.device_config.surface_flinger_native_boot.SkiaTracingFeature__use_skia_tracing true
    resetprop -n persist.sys.composition.type gpu
    resetprop -n debug.composition.type gpu
    resetprop -n debug.hwui.show_dirty_regions false
    resetprop -n debug.hwui.use_gpu_pixel_buffers false
    resetprop -n debug.hwui.use_buffer_age false
    resetprop -n persist.sys.perf.topAppRenderThreadBoost.enable true
}

NR() {
    hsin_set_gov schedutil
    hsin_apply 1 /sys/devices/system/cpu/cpu1/online
}

if [ -f "$MODDIR/.selected_option" ]; then
    SELECTED=$(cat "$MODDIR/.selected_option")
    case "$SELECTED" in
        1) vlkn ;;
        2) NR ;;
        3) echo "Skipped performance tweaks." ;;
    esac
fi

# ── Game Mode Engine ────────────────────────────────────────
hsin_game_mode() {
    LOG="$MODDIR/hsin.log"
    alog() { echo "$(date '+%H:%M:%S') [GameMode] $1" >> "$LOG"; }

    GAME_STATE="IDLE"
    CURRENT_GAME=""
    CURRENT_PROFILE=""
    LAST_APPLIED=""
    PREV_FG=""
    STABLE_FG=""
    DEBOUNCE_COUNT=0

    resolve_profile() {
        local _pkg="$1"
        if grep -qx "$_pkg" "$MODDIR/Misc/Game.txt" 2>/dev/null; then
            echo "performance"
        else
            echo "balanced"
        fi
    }

    apply_profile() {
        local _target="$1"
        local _pkg="$2"
        [ -z "$_target" ] && return

        if [ "$_target" = "$LAST_APPLIED" ] && [ "$_pkg" = "$CURRENT_GAME" ]; then
            return
        fi

        alog "Applying profile=$_target for pkg=$_pkg"

        local _pf="$MODDIR/.job_pid"
        if [ -f "$_pf" ]; then
            local _prev_pid
            _prev_pid="$(cat "$_pf" 2>/dev/null | cut -d'|' -f2)"
            if [ -n "$_prev_pid" ] && kill -0 "$_prev_pid" 2>/dev/null; then
                kill -TERM "$_prev_pid" 2>/dev/null
                local _w=0
                while kill -0 "$_prev_pid" 2>/dev/null && [ "$_w" -lt 30 ]; do
                    sleep 0.1
                    _w=$((_w + 1))
                done
                kill -0 "$_prev_pid" 2>/dev/null && kill -KILL "$_prev_pid" 2>/dev/null
            fi
        fi

        local _job_id="auto_$(date +%s)_$$"
        sh "$MODDIR/apply-profile.sh" "$_target" "$_job_id" >/dev/null 2>&1 &

        LAST_APPLIED="$_target"
        CURRENT_PROFILE="$_target"
        echo "$_target" > "$MODDIR/.applied_mode" 2>/dev/null
        echo "$_pkg|$_target|$( [ -n "$_pkg" ] && echo 1 || echo 0 )" > "$MODDIR/.auto_status" 2>/dev/null
    }

    dnd_save_state() {
        DND_WAS_ON=""
        local _zen
        _zen=$(dumpsys notification 2>/dev/null | grep -E "mZenMode=" | head -1 | grep -v "OFF")
        [ -n "$_zen" ] && DND_WAS_ON="1" && return
        if command -v settings >/dev/null 2>&1; then
            _zen=$(settings get secure zen_mode 2>/dev/null)
            [ -n "$_zen" ] && [ "$_zen" != "null" ] && [ "$_zen" != "0" ] && DND_WAS_ON="1"
        fi
    }

    dnd_apply() {
        [ -f "$MODDIR/.game_dnd" ] || return
        [ "$(cat "$MODDIR/.game_dnd" 2>/dev/null)" != "1" ] && return
        if command -v cmd >/dev/null 2>&1; then
            dnd_save_state
            cmd notification set_dnd on >/dev/null 2>&1
            alog "DND enabled for gaming"
        fi
    }

    dnd_restore() {
        [ -f "$MODDIR/.game_dnd" ] || return
        [ "$(cat "$MODDIR/.game_dnd" 2>/dev/null)" != "1" ] && return
        if command -v cmd >/dev/null 2>&1; then
            if [ "$DND_WAS_ON" = "1" ]; then
                alog "DND was already on, leaving enabled"
            else
                cmd notification set_dnd off >/dev/null 2>&1
                alog "DND restored to off"
            fi
        fi
    }

    enter_game() {
        local _pkg="$1"
        [ "$_pkg" = "$CURRENT_GAME" ] && return
        [ -z "$_pkg" ] && return

        if [ "$GAME_STATE" != "GAME_ACTIVE" ]; then
            local _baseline
            _baseline=$(cat "$MODDIR/.current_mode" 2>/dev/null)
            [ -z "$_baseline" ] && _baseline="balanced"
            echo "$_baseline" > "$MODDIR/.pre_game_mode" 2>/dev/null
        fi

        CURRENT_GAME="$_pkg"
        GAME_STATE="GAME_ACTIVE"
        echo "$_pkg" > "$MODDIR/.current_game" 2>/dev/null
        echo "GAME_ACTIVE" > "$MODDIR/.game_state" 2>/dev/null

        local _target
        _target=$(resolve_profile "$_pkg")
        apply_profile "$_target" "$_pkg"
        dnd_apply

        alog "GAME_ACTIVE: $_pkg (profile=$_target)"
    }

    exit_game() {
        [ "$GAME_STATE" != "GAME_ACTIVE" ] && return
        [ -z "$CURRENT_GAME" ] && return

        dnd_restore

        local _old_game="$CURRENT_GAME"
        CURRENT_GAME=""
        GAME_STATE="IDLE"
        echo "" > "$MODDIR/.current_game" 2>/dev/null
        echo "IDLE" > "$MODDIR/.game_state" 2>/dev/null

        # ── SINGLE SOURCE OF TRUTH: .current_mode ──────────────
        # apply-profile.sh writes .current_mode at START.
        # When user manually picks a mode, .current_mode = that mode.
        # When game exits, stay on whatever .current_mode says.
        # Do NOT force back to balanced.

        local _mode
        _mode=$(cat "$MODDIR/.current_mode" 2>/dev/null)
        [ -z "$_mode" ] && _mode="balanced"

        apply_profile "$_mode" ""
        rm -f "$MODDIR/.pre_game_mode" 2>/dev/null

        alog "IDLE: exited game $_old_game, preserved mode: $_mode"
    }

    check_power_save() {
        local _ps=""
        if command -v settings >/dev/null 2>&1; then
            local _raw
            _raw=$(settings get global low_power 2>/dev/null)
            [ "$_raw" = "1" ] && _ps="1"
        fi
        if [ -z "$_ps" ] && command -v cmd >/dev/null 2>&1; then
            _raw=$(cmd power get-low-power-mode 2>/dev/null)
            case "$_raw" in
                *1*|*true*|*on*) _ps="1" ;;
            esac
        fi

        if [ "$_ps" = "1" ]; then
            if [ "$GAME_STATE" != "POWER_SAVE" ]; then
                if [ "$GAME_STATE" = "IDLE" ]; then
                    local _baseline
                    _baseline=$(cat "$MODDIR/.current_mode" 2>/dev/null)
                    [ -z "$_baseline" ] && _baseline="balanced"
                    echo "$_baseline" > "$MODDIR/.pre_powersave_mode" 2>/dev/null
                fi
                GAME_STATE="POWER_SAVE"
                echo "POWER_SAVE" > "$MODDIR/.game_state" 2>/dev/null
                apply_profile "battery" ""
                alog "POWER_SAVE: battery saver activated"
            fi
            return 0
        fi
        return 1
    }

    exit_power_save() {
        if [ "$GAME_STATE" = "POWER_SAVE" ]; then
            if [ -n "$CURRENT_GAME" ]; then
                local _target
                _target=$(resolve_profile "$CURRENT_GAME")
                apply_profile "$_target" "$CURRENT_GAME"
                GAME_STATE="GAME_ACTIVE"
                echo "GAME_ACTIVE" > "$MODDIR/.game_state" 2>/dev/null
                alog "POWER_SAVE ended: restored game profile for $CURRENT_GAME"
            else
                # ── SINGLE SOURCE OF TRUTH ──────────────────────
                local _mode
                _mode=$(cat "$MODDIR/.current_mode" 2>/dev/null)
                [ -z "$_mode" ] && _mode="balanced"

                apply_profile "$_mode" ""
                rm -f "$MODDIR/.pre_powersave_mode" 2>/dev/null
                GAME_STATE="IDLE"
                echo "IDLE" > "$MODDIR/.game_state" 2>/dev/null
                alog "POWER_SAVE ended: restored to $_mode"
            fi
        fi
    }

    get_foreground_pkg() {
        local _fg=""
        _fg=$(dumpsys activity activities 2>/dev/null | grep -E "mResumedActivity|topResumedActivity" | head -1 | grep -oE "u0 [a-zA-Z0-9._]+" | awk '{print $2}')
        if [ -z "$_fg" ]; then
            _fg=$(dumpsys window 2>/dev/null | grep -E "mCurrentFocus.*Application" | head -1 | sed 's/.*{[^}]* \([^ ]*\)\/.*/\1/')
        fi
        if [ -z "$_fg" ]; then
            _fg=$(dumpsys window 2>/dev/null | grep -E "mFocusedApp" | head -1 | grep -oE '[a-zA-Z][a-zA-Z0-9_.]*\/[a-zA-Z0-9_.]+' | head -1 | cut -d/ -f1)
        fi
        echo "$_fg"
    }

    process_fg() {
        local _fg="$1"
        [ -z "$_fg" ] && return
        [ "$_fg" = "$PREV_FG" ] && return

        case "$_fg" in
            com.android.systemui|surfaceflinger|system_server|android)
                PREV_FG="$_fg"
                return
                ;;
        esac

        if check_power_save; then
            PREV_FG="$_fg"
            return
        fi

        exit_power_save

        local _is_game=0
        grep -qx "$_fg" "$MODDIR/Misc/Game.txt" 2>/dev/null && _is_game=1

        if [ "$_is_game" = "1" ]; then
            enter_game "$_fg"
        else
            if [ "$GAME_STATE" = "GAME_ACTIVE" ]; then
                exit_game
            fi
        fi

        PREV_FG="$_fg"
    }

    alog "Game Mode engine started (debounced polling, interval=2s)"

    while true; do
        local AUTO
        AUTO=$(cat "$MODDIR/.auto_mode" 2>/dev/null)
        if [ "$AUTO" != "1" ]; then
            echo "0" > "$MODDIR/.auto_applied" 2>/dev/null
            echo "|balanced|0" > "$MODDIR/.auto_status" 2>/dev/null
            LAST_APPLIED=""
            CURRENT_GAME=""
            GAME_STATE="IDLE"
            STABLE_FG=""
            DEBOUNCE_COUNT=0
            while :; do
                sleep 1
                AUTO=$(cat "$MODDIR/.auto_mode" 2>/dev/null)
                [ "$AUTO" = "1" ] && break
            done
            alog "Game Mode toggled ON, starting detection"
            continue
        fi

        local FG
        FG=$(get_foreground_pkg)

        if [ "$FG" = "$LAST_FG" ] && [ -n "$FG" ]; then
            DEBOUNCE_COUNT=$((DEBOUNCE_COUNT + 1))
        else
            DEBOUNCE_COUNT=0
            LAST_FG="$FG"
        fi

        if [ "$DEBOUNCE_COUNT" -ge 2 ] && [ "$FG" != "$STABLE_FG" ]; then
            STABLE_FG="$FG"
            process_fg "$FG"
        fi

        sleep 2
    done
}

# ── Power Save Monitor ──────────────────────────────────────
hsin_powersave_monitor() {
    LOG="$MODDIR/hsin.log"
    local _prev_ps=""

    while true; do
        sleep 10

        local _ps=""
        if command -v settings >/dev/null 2>&1; then
            local _raw
            _raw=$(settings get global low_power 2>/dev/null)
            [ "$_raw" = "1" ] && _ps="1"
        fi
        if [ -z "$_ps" ] && command -v cmd >/dev/null 2>&1; then
            _raw=$(cmd power get-low-power-mode 2>/dev/null)
            case "$_raw" in
                *1*|*true*|*on*) _ps="1" ;;
            esac
        fi

        if [ "$_ps" != "$_prev_ps" ]; then
            _prev_ps="$_ps"
            if [ "$_ps" = "1" ]; then
                echo "$(date '+%H:%M:%S') [PowerSave] Battery saver activated" >> "$LOG" 2>/dev/null
            else
                echo "$(date '+%H:%M:%S') [PowerSave] Battery saver deactivated" >> "$LOG" 2>/dev/null
            fi
        fi
    done
}

# ── Start engines ───────────────────────────────────────────
hsin_game_mode &
hsin_powersave_monitor &

exit 0
