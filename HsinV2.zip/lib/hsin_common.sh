#!/system/bin/sh

case "$MODDIR" in
	""|*/lib) MODDIR="$(cd "$(dirname "$0")/.." 2>/dev/null && pwd)" ;;
esac
[ -n "$MODDIR" ] || MODDIR="$(cd "$(dirname "$0")" 2>/dev/null && pwd)"
HSIN_LOG="${HSIN_LOG:-$MODDIR/hsin.log}"
HSIN_UI_LOG="${HSIN_UI_LOG:-$MODDIR/hsin_ui.log}"
HSIN_RB_DIR="${HSIN_RB_DIR:-$MODDIR/.rollback}"
HSIN_STATE_DIR="${HSIN_STATE_DIR:-$MODDIR/.hsin_state}"
HSIN_FEATURE_STATUS="${HSIN_FEATURE_STATUS:-$MODDIR/.feature_status}"

HSIN_SYSROOT="${HSIN_SYSROOT:-}"
HSIN_DRYRUN="${HSIN_DRYRUN:-0}"

HSIN_PROFILE_STATUS_FILE="${HSIN_PROFILE_STATUS_FILE:-$MODDIR/.profile_status}"
HSIN_JOB_ID=""
_HSIN_PROFILE_CANCELLED=0

_hs_init_job() {
	[ -n "$HSIN_JOB_ID" ] && return 0
	[ -f "$HSIN_PROFILE_STATUS_FILE" ] || return 0
	HSIN_JOB_ID="$(sed -n '1p' "$HSIN_PROFILE_STATUS_FILE" 2>/dev/null | cut -d'|' -f1)"
}
_hs_init_job

_hs_check_job() {
	[ "$_HSIN_PROFILE_CANCELLED" = "1" ] && return 1
	[ -f "$HSIN_PROFILE_STATUS_FILE" ] || return 0
	[ -z "$HSIN_JOB_ID" ] && return 0
	_cur_id="$(sed -n '1p' "$HSIN_PROFILE_STATUS_FILE" 2>/dev/null | cut -d'|' -f1)"
	[ "$_cur_id" != "$HSIN_JOB_ID" ] && {
		_HSIN_PROFILE_CANCELLED=1
		return 1
	}
	return 0
}

hsin_syspath() {
	_path="$1"
	if [ -n "$HSIN_SYSROOT" ]; then
		case "$_path" in
			/sys/*|/proc/*|/dev/*) echo "${HSIN_SYSROOT}${_path}" ;;
			*) echo "$_path" ;;
		esac
		return
	fi
	echo "$_path"
}

hsin_syspath_set() {
	if [ -n "$HSIN_SYSROOT" ]; then
		case "$1" in
			/sys/*|/proc/*|/dev/*) _HSIN_SP="${HSIN_SYSROOT}$1" ;;
			*) _HSIN_SP="$1" ;;
		esac
	else
		_HSIN_SP="$1"
	fi
}

_HSIN_LOG_DIR_READY=0
_HSIN_LOG_BUF=""
_HSIN_LOG_BUF_COUNT=0
HSIN_LOG_FLUSH_INTERVAL="${HSIN_LOG_FLUSH_INTERVAL:-50}"

hsin_log_flush() {
	[ -z "$_HSIN_LOG_BUF" ] && return 0
	if [ "$_HSIN_LOG_DIR_READY" != "1" ]; then
		mkdir -p "$(dirname "$HSIN_LOG")" 2>/dev/null
		_HSIN_LOG_DIR_READY=1
	fi
	printf '%s\n' "$_HSIN_LOG_BUF" >> "$HSIN_LOG" 2>/dev/null
	_HSIN_LOG_BUF=""
	_HSIN_LOG_BUF_COUNT=0
}

hsin_log() {
	_tag="${1:-HSIN}"; _msg="$2"
	_entry="$(date '+%H:%M:%S') [$_tag] $_msg"
	if [ -z "$_HSIN_LOG_BUF" ]; then
		_HSIN_LOG_BUF="$_entry"
	else
		_HSIN_LOG_BUF="$_HSIN_LOG_BUF
$_entry"
	fi
	_HSIN_LOG_BUF_COUNT=$((_HSIN_LOG_BUF_COUNT + 1))
	[ "$_HSIN_LOG_BUF_COUNT" -ge "$HSIN_LOG_FLUSH_INTERVAL" ] && hsin_log_flush
}

trap 'hsin_log_flush' EXIT HUP

hsin_skip()           { hsin_log "SKIP"        "[$1] $2"; }
hsin_not_supported()  { hsin_log "UNSUPPORTED" "[$1] $2"; }
hsin_fail()           { hsin_log "FAIL"        "[$1] $2"; }
hsin_ok()             { hsin_log "OK"          "[$1] $2"; }
hsin_warn()           { hsin_log "WARN"        "[$1] $2"; }

hsin_normalize_cpuset() {
	_in="$1"
	_out=""
	for _p in $(echo "$_in" | tr ',' ' '); do
		_p="$(echo "$_p" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
		case "$_p" in
			*-*)
				_s="${_p%%-*}"
				_e="${_p#*-}"
				_i="$_s"
				while [ "$_i" -le "$_e" ] 2>/dev/null; do
					[ -n "$_out" ] && _out="${_out},"
					_out="${_out}${_i}"
					_i=$((_i + 1))
				done
				;;
			*)
				[ -n "$_out" ] && _out="${_out},"
				_out="${_out}${_p}"
				;;
		esac
	done
	echo "$_out"
}

hsin_normalize_scheduler() {
	echo "$1" | sed -n 's/.*\[\([^]]*\)\].*/\1/p'
}

hsin_normalized_eq() {
	_path="$1"; _cur="$2"; _tgt="$3"
	[ "$_cur" = "$_tgt" ] && return 0

	case "$_cur" in
		*"[$_tgt]"*) return 0 ;;
	esac

	case "$_path" in
		*/cpuset/*)
			_nc="$(hsin_normalize_cpuset "$_cur")"
			_nt="$(hsin_normalize_cpuset "$_tgt")"
			[ "$_nc" = "$_nt" ] && return 0
			;;
	esac

	case "$_path" in
		*/scheduler)
			_ns="$(hsin_normalize_scheduler "$_cur")"
			_nt="$(hsin_normalize_scheduler "$_tgt")"
			[ "$_ns" = "$_nt" ] && return 0
			;;
	esac

	return 1
}

hsin_feature_status() {
	_feat="$1"; _applied="${2:-0}"; _skipped="${3:-0}"; _errors="${4:-0}"
	_unsupported="${5:-0}"; _critical="${6:-0}"; _duration="${7:-0}"
	_status="applied"
	[ "$_applied" -eq 0 ] && [ "$_skipped" -gt 0 ] && [ "$_errors" -eq 0 ] && _status="skipped"
	[ "$_errors" -gt 0 ] && [ "$_critical" -eq 0 ] && _status="warning"
	[ "$_critical" -gt 0 ] && _status="error"
	echo "${_feat}|${_status}|${_applied}|${_skipped}|${_unsupported}|${_errors}|${_critical}|${_duration}" >> "$HSIN_FEATURE_STATUS" 2>/dev/null
}

_HSIN_RB_DIR_READY=0
hsin_rb_init() {
	[ "$_HSIN_RB_DIR_READY" = "1" ] && return 0
	mkdir -p "$HSIN_RB_DIR" 2>/dev/null
	_HSIN_RB_DIR_READY=1
}
hsin_rb_save() {
	hsin_rb_init
	_k="${3:-$(hsin_rb_key "$1")}"
	printf '%s\n%s\n' "$1" "$2" > "$HSIN_RB_DIR/$_k" 2>/dev/null
}
hsin_rb_key() {
	_kp="$1"; _kk=""
	while [ -n "$_kp" ]; do
		case "$_kp" in
			/*) _kk="${_kk}_"; _kp="${_kp#/}" ;;
			*)
				_kc="${_kp%%/*}"
				case "$_kp" in */*) _kp="${_kp#*/}" ;; *) _kp="" ;; esac
				_kk="${_kk}${_kc}"
				[ -n "$_kp" ] && _kk="${_kk}_"
				;;
		esac
	done
	echo "$_kk"
}
hsin_rb_get() {
	sed -n '2p' "$HSIN_RB_DIR/$(hsin_rb_key "$1")" 2>/dev/null
}
hsin_target_save() {
	hsin_rb_init
	_k="${3:-$(hsin_rb_key "$1")}"
	printf '%s\n%s\n' "$1" "$2" > "$HSIN_RB_DIR/${_k}.tgt" 2>/dev/null
}
hsin_target_get() {
	sed -n '2p' "$HSIN_RB_DIR/$(hsin_rb_key "$1").tgt" 2>/dev/null
}

HSIN_DEDUP_FILE="${HSIN_DEDUP_FILE:-$MODDIR/.apply_dedup}"

hsin_dedup_check() {
	[ -f "$HSIN_DEDUP_FILE" ] || return 1
	grep -qFx "$1" "$HSIN_DEDUP_FILE" 2>/dev/null
}
hsin_dedup_add() {
	echo "$1" >> "$HSIN_DEDUP_FILE" 2>/dev/null
}

hsin_cap_node() { hsin_syspath_set "$1"; [ -e "$_HSIN_SP" ]; }

hsin_cap_writable() {
	_t="$(hsin_syspath "$1")"
	[ -e "$_t" ] || return 1
	[ "$HSIN_DRYRUN" = "1" ] && return 0
	[ -w "$_t" ]
}

hsin_cap_cmd() { command -v "$1" >/dev/null 2>&1; }
hsin_cap_prop() { hsin_cap_cmd getprop || hsin_cap_cmd resetprop; }

hsin_cap_glob_dir() {
	_dir="$(hsin_syspath "$1")"
	[ -d "$_dir" ] || return 1
	ls "$_dir" 2>/dev/null | grep -q "$2"
}

android_perf_extra_revert() {
	if command -v cmd >/dev/null 2>&1; then
		cmd power set-fixed-performance-mode-enabled false >/dev/null 2>&1
		cmd power set-adaptive-power-saver-enabled true >/dev/null 2>&1
		cmd power set-maximum-performance false >/dev/null 2>&1
	fi
	if command -v settings >/dev/null 2>&1; then
		settings put global aggressive_idle_enabled 0 >/dev/null 2>&1
		settings put global aggressive_standby_enabled 0 >/dev/null 2>&1
	fi
}

hsin_apply() {
	_val="$1"; _path="$2"
	[ -n "$_path" ] || return 1
	_hs_check_job || { return 4; }
	hsin_dedup_check "$_path" && return 0
	hsin_syspath_set "$_path"; _t="$_HSIN_SP"
	[ -f "$_t" ] || { hsin_not_supported "apply" "$_path (node absent)"; return 2; }
	_key="$(hsin_rb_key "$_path")"

	_prev="$(cat "$_t" 2>/dev/null)"

	if [ -n "$_prev" ] && hsin_normalized_eq "$_path" "$_prev" "$_val"; then
		hsin_skip "apply" "$_path already set to '$_val'"
		hsin_rb_save "$_path" "$_prev" "$_key"
		hsin_target_save "$_path" "$_val" "$_key"
		hsin_dedup_add "$_path"
		return 0
	fi

	if [ "$HSIN_DRYRUN" = "1" ]; then
		echo "$_val" > "$_t" 2>/dev/null
		hsin_rb_save "$_path" "$_prev" "$_key"
		hsin_target_save "$_path" "$_val" "$_key"
		hsin_dedup_add "$_path"
		hsin_log "DRYRUN" "apply '$_val' -> $_path (prev='$_prev')"
		return 0
	fi

	if [ ! -w "$_t" ]; then
		chmod 644 "$_t" 2>/dev/null
		[ -w "$_t" ] || { hsin_skip "apply" "$_path (not writable)"; return 3; }
	fi
	echo "$_val" > "$_t" 2>/dev/null

	_after="$(cat "$_t" 2>/dev/null)"
	if hsin_normalized_eq "$_path" "$_after" "$_val"; then
		: # match
	elif [ "$_after" = "$_prev" ]; then
		hsin_skip "apply" "$_path locked at '$_after'"
		hsin_dedup_add "$_path"
		return 0
	else
		hsin_fail "apply" "$_path requested='$_val' after='$_after'"
		[ -n "$_prev" ] && echo "$_prev" > "$_t" 2>/dev/null
		return 1
	fi
	hsin_rb_save "$_path" "$_prev" "$_key"
	hsin_target_save "$_path" "$_val" "$_key"
	hsin_dedup_add "$_path"
	hsin_ok "apply" "$_path := '$_val'"
	return 0
}

hsin_write() {
	_val="$1"; _path="$2"
	[ -n "$_path" ] || return 1
	_hs_check_job || { return 4; }
	hsin_dedup_check "$_path" && return 0
	hsin_syspath_set "$_path"; _t="$_HSIN_SP"
	[ -f "$_t" ] || { hsin_not_supported "write" "$_path (node absent)"; return 2; }
	_key="$(hsin_rb_key "$_path")"
	_prev="$(cat "$_t" 2>/dev/null)"

	if [ -n "$_prev" ] && hsin_normalized_eq "$_path" "$_prev" "$_val"; then
		hsin_skip "write" "$_path already set to '$_val'"
		hsin_rb_save "$_path" "$_prev" "$_key"
		hsin_target_save "$_path" "$_val" "$_key"
		hsin_dedup_add "$_path"
		return 0
	fi

	if [ "$HSIN_DRYRUN" = "1" ]; then
		echo "$_val" > "$_t" 2>/dev/null
		hsin_rb_save "$_path" "$_prev" "$_key"
		hsin_target_save "$_path" "$_val" "$_key"
		hsin_dedup_add "$_path"
		hsin_log "DRYRUN" "write '$_val' -> $_path"
		return 0
	fi

	if [ ! -w "$_t" ]; then
		chmod 644 "$_t" 2>/dev/null
		[ -w "$_t" ] || { hsin_skip "write" "$_path (not writable)"; return 3; }
	fi
	echo "$_val" > "$_t" 2>/dev/null
	_after="$(cat "$_t" 2>/dev/null)"
	if [ -n "$_after" ] && [ "$_after" != "$_val" ] && [ "$_after" = "$_prev" ]; then
		hsin_skip "write" "$_path locked at '$_after'"
	else
		hsin_rb_save "$_path" "$_prev" "$_key"
		hsin_target_save "$_path" "$_val" "$_key"
		hsin_log "OK" "[write] $_path := '$_val'"
	fi
	hsin_dedup_add "$_path"
	return 0
}

hsin_override_apply() {
	_val="$1"; _path="$2"
	[ -n "$_path" ] || return 1
	_hs_check_job || { return 4; }
	hsin_dedup_remove "$_path" 2>/dev/null
	hsin_apply "$_val" "$_path"
}

hsin_dedup_remove() {
	[ -f "$HSIN_DEDUP_FILE" ] || return 0
	_tmp="${HSIN_DEDUP_FILE}.tmp"
	grep -vFx "$1" "$HSIN_DEDUP_FILE" > "$_tmp" 2>/dev/null
	mv "$_tmp" "$HSIN_DEDUP_FILE" 2>/dev/null
}

hsin_rollback_node() {
	_path="$1"
	_prev="$(hsin_rb_get "$_path")"
	[ -n "$_prev" ] || { hsin_log "ROLLBACK" "no saved value for $_path"; return 0; }
	_t="$(hsin_syspath "$_path")"
	[ -f "$_t" ] || return 0
	if [ "$HSIN_DRYRUN" = "1" ]; then
		echo "$_prev" > "$_t" 2>/dev/null
		hsin_log "DRYRUN" "rollback $_path -> '$_prev'"
		return 0
	fi
	if [ ! -w "$_t" ]; then chmod 644 "$_t" 2>/dev/null; fi
	echo "$_prev" > "$_t" 2>/dev/null
	hsin_log "ROLLBACK" "$_path -> '$_prev'"
}

hsin_rollback_all() {
	hsin_rb_init
	for _f in "$HSIN_RB_DIR"/*; do
		[ -f "$_f" ] || continue
		case "$_f" in *.tgt) continue ;; esac
		_node="$(sed -n '1p' "$_f" 2>/dev/null)"
		[ -n "$_node" ] || continue
		hsin_rollback_node "$_node"
	done
}

hsin_verify_node() {
	_path="$1"
	_tgt="$(hsin_target_get "$_path")"
	[ -n "$_tgt" ] || { hsin_log "VERIFY" "SKIP $_path (no target recorded)"; return 2; }
	hsin_syspath_set "$_path"
	_cur="$(cat "$_HSIN_SP" 2>/dev/null)"

	if hsin_normalized_eq "$_path" "$_cur" "$_tgt"; then
		hsin_log "VERIFY" "PASS $_path (cur=$_cur, expected=$_tgt)"
		return 0
	fi

	hsin_fail "verify" "$_path current='$_cur' expected='$_tgt'"
	return 1
}

hsin_verify_all() {
	_ok=0; _bad=0
	hsin_rb_init
	for _f in "$HSIN_RB_DIR"/*.tgt; do
		[ -f "$_f" ] || continue
		_node="$(sed -n '1p' "$_f" 2>/dev/null)"
		[ -n "$_node" ] || continue
		if hsin_verify_node "$_node"; then _ok=$((_ok+1)); else _bad=$((_bad+1)); fi
	done
	hsin_log "VERIFY" "summary ok=$_ok fail=$_bad"
	[ "$_bad" -eq 0 ]
}

hsin_maxfreq() { tr ' ' '\n' < "$1" 2>/dev/null | grep -v '^[[:space:]]*$' | sort -nr | head -n 1; }
hsin_minfreq() { tr ' ' '\n' < "$1" 2>/dev/null | grep -v '^[[:space:]]*$' | sort -n | head -n 1; }
hsin_midfreq() {
	_f="$1"
	_total="$(wc -w < "$_f" 2>/dev/null)"
	_mid="$(( (${_total:-0} + 1) / 2 ))"
	tr ' ' '\n' < "$_f" 2>/dev/null | grep -v '^[[:space:]]*$' | sort -nr | head -n "$_mid" | tail -n 1
}

hsin_set_gov() {
	_gov="$1"
	for _p in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor \
	         /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do
		[ -f "$(hsin_syspath "$_p")" ] || continue
		_avail="$(hsin_syspath "${_p%/*}/scaling_available_governors")"
		if [ -f "$_avail" ] && ! grep -qw "$_gov" "$_avail" 2>/dev/null; then
			hsin_not_supported "gov" "$_p (governor '$_gov' unavailable)"; continue
		fi
		hsin_apply "$_gov" "$_p"
	done
}

hsin_run() {
	if [ "$HSIN_DRYRUN" = "1" ]; then
		hsin_log "DRYRUN" "run: $*"
		return 0
	fi
	"$@" >> "$HSIN_LOG" 2>&1
}

HSIN_COMMON_LOADED=1
