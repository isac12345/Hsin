#!/system/bin/sh
# HSIN Apply Profile — v2.2 Surgical Fix
# - .current_mode written at START (before execution)
# - Progress estimated from elapsed time (no race conditions)
# - Simple, reliable status format

MODDIR="${0%/*}"
[ -z "$MODDIR" ] && MODDIR="$(cd "$(dirname "$0")" && pwd)"

PROFILE="${1:-}"
JOB_ID="${2:-}"

EXEC_TIMEOUT_SEC=60
STATUS_FILE="$MODDIR/.profile_status"
LOG="$MODDIR/hsin.log"
PROGRESS_FILE="$MODDIR/.progress"
PID_FILE="$MODDIR/.job_pid"
LOCK_FILE="$MODDIR/.hsin.lock"

TOTAL_FEATURES=10

case "$PROFILE" in
    performance|balanced|battery) ;;
    *) echo "Usage: $0 <performance|balanced|battery> <job_id>" >&2; exit 1 ;;
esac
[ -z "$JOB_ID" ] && JOB_ID="job_$(date +%s)_$$"

now_ts() { date +%s 2>/dev/null || echo 0; }

write_status() {
    _phase="$1"
    _done="${2:-0}"
    _elapsed="${3:-0}"
    printf '%s|%s|%s|0|0|0|0|%s|0|%s|%s|0|none|%s||||\n'         "$JOB_ID" "$PROFILE" "$_phase" "$_elapsed" "$TOTAL_FEATURES" "$_done" "$_elapsed"         > "$STATUS_FILE" 2>/dev/null
}

log_msg() {
    echo "$(date '+%H:%M:%S') [ApplyProfile] $1" >> "$LOG" 2>/dev/null
}

# ── CRITICAL: Save mode immediately ─────────────────────────
echo "$PROFILE" > "$MODDIR/.current_mode" 2>/dev/null
echo "status=applying" > "$MODDIR/.profile_state" 2>/dev/null
echo "applied=$PROFILE" >> "$MODDIR/.profile_state" 2>/dev/null

# ── Lock ────────────────────────────────────────────────────
exec 200>"$LOCK_FILE"
if ! flock -n 200; then
    log_msg "job=$JOB_ID waiting for lock..."
    flock 200 || { log_msg "job=$JOB_ID lock failed"; exit 2; }
fi

# ── Preempt old job ─────────────────────────────────────────
if [ -f "$PID_FILE" ]; then
    _prev="$(cat "$PID_FILE" 2>/dev/null)"
    _prev_job="${_prev%%|*}"
    _prev_pid="${_prev##*|}"
    if [ -n "$_prev_pid" ] && [ "$_prev_job" != "$JOB_ID" ] && kill -0 "$_prev_pid" 2>/dev/null; then
        kill -TERM "$_prev_pid" 2>/dev/null
        sleep 0.5
        kill -KILL "$_prev_pid" 2>/dev/null
    fi
fi

: > "$PROGRESS_FILE" 2>/dev/null
: > "$MODDIR/.progress_log" 2>/dev/null

write_status "applying" 0 0
log_msg "job=$JOB_ID START profile=$PROFILE"

START_TS=$(now_ts)
PROFILE_SCRIPT="$MODDIR/profile/$PROFILE"

if [ ! -f "$PROFILE_SCRIPT" ]; then
    write_status "failed" 0 0
    log_msg "FAILED: profile script not found: $PROFILE_SCRIPT"
    flock -u 200 2>/dev/null
    exit 1
fi

# ── Execute profile ─────────────────────────────────────────
sh "$PROFILE_SCRIPT" "" "$PROFILE" >> "$LOG" 2>&1 &
_PROFILE_PID=$!
echo "$JOB_ID|$_PROFILE_PID" > "$PID_FILE" 2>/dev/null

elapsed=0
_rc=0
while kill -0 "$_PROFILE_PID" 2>/dev/null; do
    # Estimate progress: typical profile takes ~5-8s, scale linearly
    _est_done=$(( (elapsed * TOTAL_FEATURES) / 8 ))
    [ "$_est_done" -gt "$TOTAL_FEATURES" ] && _est_done=$TOTAL_FEATURES
    write_status "applying" "$_est_done" "$elapsed"

    if [ "$elapsed" -ge "$EXEC_TIMEOUT_SEC" ]; then
        kill -TERM "$_PROFILE_PID" 2>/dev/null
        sleep 1
        kill -KILL "$_PROFILE_PID" 2>/dev/null
        _rc=124
        break
    fi
    sleep 1
    elapsed=$((elapsed + 1))
done

if [ "$_rc" -ne 124 ]; then
    wait "$_PROFILE_PID" 2>/dev/null
    _rc=$?
fi

APPLY_ELAPSED=$(($(now_ts) - START_TS))

# ── Final status ────────────────────────────────────────────
if [ "$_rc" -eq 124 ]; then
    write_status "timeout" "$TOTAL_FEATURES" "$APPLY_ELAPSED"
    log_msg "job=$JOB_ID TIMEOUT after ${EXEC_TIMEOUT_SEC}s"
    flock -u 200 2>/dev/null
    exit 1
fi

# Count OK/FAIL from log
_ok=0; _skip=0; _fail=0
if [ -f "$LOG" ]; then
    _ok=$(grep -c "\[OK\]" "$LOG" 2>/dev/null || echo 0)
    _skip=$(grep -c "\[SKIP\]" "$LOG" 2>/dev/null || echo 0)
    _fail=$(grep -c "\[FAIL\]" "$LOG" 2>/dev/null || echo 0)
fi

_final="applied"
[ "$_fail" -gt 0 ] && _final="partial"
[ "$_rc" -ne 0 ] && _final="failed"

write_status "$_final" "$TOTAL_FEATURES" "$APPLY_ELAPSED"
log_msg "job=$JOB_ID END status=$_final ok=$_ok skip=$_skip fail=$_fail elapsed=${APPLY_ELAPSED}s"

# ── Save state ──────────────────────────────────────────────
echo "status=$_final" > "$MODDIR/.profile_state" 2>/dev/null
echo "applied=$PROFILE" >> "$MODDIR/.profile_state" 2>/dev/null
echo "timestamp=$(date '+%Y-%m-%d %H:%M:%S')" >> "$MODDIR/.profile_state" 2>/dev/null

flock -u 200 2>/dev/null
[ "$_final" = "failed" ] && exit 1
exit 0
